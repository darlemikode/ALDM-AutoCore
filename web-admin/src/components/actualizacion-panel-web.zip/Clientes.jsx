import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api";
import DataTable from "../components/DataTable";
import ClienteFormModal from "../components/ClienteFormModal";
import { useUI } from "../context/UIContext";
import { useAuth } from "../context/AuthContext";

export default function Clientes() {
  const { confirmDialog, notify } = useUI();
  const { hasPermission } = useAuth();
  const [clientes, setClientes] = useState([]);
  const [q, setQ] = useState("");
  const [editing, setEditing] = useState(null); // null = cerrado, {} = crear, {...} = editar
  const [loading, setLoading] = useState(true);
  const [invitacion, setInvitacion] = useState(null); // { cliente, codigo_invitacion }

  async function load() {
    setLoading(true);
    const data = await api.get(`/clientes/?${q ? `q=${encodeURIComponent(q)}&` : ""}solo_activos=true`);
    setClientes(data);
    setLoading(false);
  }

  useEffect(() => {
    const t = setTimeout(load, 250);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q]);

  async function handleSave(values) {
    if (editing?.id_cliente) {
      await api.put(`/clientes/${editing.id_cliente}`, values);
    } else {
      await api.post("/clientes/", values);
    }
    setEditing(null);
    load();
  }

  async function handleDelete(cliente) {
    const ok = await confirmDialog(`¿Dar de baja a ${cliente.nombre_cliente}? Su historial de servicios se conserva.`, { danger: true });
    if (!ok) return;
    try {
      await api.del(`/clientes/${cliente.id_cliente}`);
      load();
      notify("Cliente dado de baja.", "success");
    } catch (err) {
      notify(err.message, "error");
    }
  }

  async function invitar(cliente) {
    try {
      const res = await api.post(`/clientes/${cliente.id_cliente}/invitar`);
      setInvitacion({ cliente, ...res });
    } catch (err) {
      notify(err.message, "error");
    }
  }

  return (
    <>
      <div className="page-header">
        <div>
          <h1>🧑 Clientes</h1>
          <div className="subtitle">{clientes.length} cliente(s) activos</div>
        </div>
        <button className="btn btn-primary" onClick={() => setEditing({})}>
          🧑 Nuevo cliente
        </button>
      </div>

      <div className="panel">
        <div className="toolbar">
          <input
            className="search-input"
            placeholder="Buscar por nombre, cuenta, empresa, teléfono o correo…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
        </div>

        {loading ? (
          <div className="loading-text">Cargando…</div>
        ) : (
          <DataTable
            columns={[
              {
                key: "cuenta",
                label: "Cuenta",
                render: (c) => <span className="mono" style={{ fontSize: 12, color: "var(--ink-500)" }}>{c.numero_cuenta}</span>,
              },
              {
                key: "nombre",
                label: "Nombre",
                render: (c) => (
                  <Link to={`/vehiculos?id_cliente=${c.id_cliente}`}>
                    {c.nombre_cliente} {c.paterno_cliente}
                  </Link>
                ),
              },
              { key: "empresa_cliente", label: "Empresa" },
              { key: "telefono1", label: "Teléfono" },
              { key: "correo_cliente", label: "Correo" },
              {
                key: "app",
                label: "App cliente",
                render: (c) => (c.cuenta_activada ? <span className="badge badge-teal">Activa</span> : <span className="badge badge-grey">Sin activar</span>),
              },
            ]}
            rows={clientes}
            onEdit={setEditing}
            onDelete={hasPermission("clientes.eliminar") ? handleDelete : undefined}
            extraActions={(c) =>
              hasPermission("clientes.editar") && !c.cuenta_activada ? (
                <button className="btn btn-secondary btn-sm" onClick={() => invitar(c)}>
                  Invitar a la app
                </button>
              ) : null
            }
            emptyMessage="No hay clientes registrados todavía. Crea el primero."
          />
        )}
      </div>

      {editing && (
        <ClienteFormModal
          title={editing.id_cliente ? `Editar cliente — ${editing.numero_cuenta || ""}` : "Nuevo cliente"}
          initialValues={editing}
          onSubmit={handleSave}
          onClose={() => setEditing(null)}
        />
      )}

      {invitacion && (
        <div className="modal-backdrop" onClick={(e) => e.target === e.currentTarget && setInvitacion(null)}>
          <div className="modal" style={{ maxWidth: 400 }}>
            <h2 style={{ fontSize: 18 }}>Invitación para {invitacion.cliente.nombre_cliente}</h2>
            <p style={{ color: "var(--ink-500)", fontSize: 13 }}>
              Comunícale este código tú mismo (llamada, WhatsApp) junto con el teléfono o correo con el que está
              registrado — lo va a necesitar para activar su cuenta en la app.
            </p>
            <div className="mono" style={{ background: "var(--paper-0)", padding: "12px 16px", borderRadius: 8, fontSize: 22, textAlign: "center", letterSpacing: 3, fontWeight: 700 }}>
              {invitacion.codigo_invitacion}
            </div>
            <div style={{ fontSize: 12, color: "var(--ink-500)", marginTop: 8 }}>
              Identificador para activar: <b>{invitacion.telefono1 || invitacion.correo_cliente}</b>
            </div>
            <div className="modal-actions">
              <button className="btn btn-primary" onClick={() => setInvitacion(null)}>Listo</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
