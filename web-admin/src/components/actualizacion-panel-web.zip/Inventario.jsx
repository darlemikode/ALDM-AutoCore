import { useEffect, useState } from "react";
import { api } from "../api";
import DataTable from "../components/DataTable";
import FormModal from "../components/FormModal";
import { useUI } from "../context/UIContext";

const ZONAS_ABC = [
  { value: "A", label: "A — rota mucho" },
  { value: "B", label: "B — rota normal" },
  { value: "C", label: "C — rota poco" },
];

export default function Inventario() {
  const { notify } = useUI();
  const [refacciones, setRefacciones] = useState([]);
  const [marcasRefaccion, setMarcasRefaccion] = useState([]);
  const [proveedores, setProveedores] = useState([]);
  const [marcasVehiculo, setMarcasVehiculo] = useState([]);
  const [modelosVehiculo, setModelosVehiculo] = useState([]);
  const [editing, setEditing] = useState(null);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const [refs, marcasRef, provs, marcasVeh, modelosVeh] = await Promise.all([
      api.get("/refacciones/"), api.get("/refacciones-marcas/"), api.get("/proveedores/"),
      api.get("/vehiculos-marcas/"), api.get("/vehiculos-modelos/"),
    ]);
    setRefacciones(refs);
    setMarcasRefaccion(marcasRef);
    setProveedores(provs);
    setMarcasVehiculo(marcasVeh);
    setModelosVehiculo(modelosVeh);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  function estaCompleto(r) {
    return !!(r.id_marca_vehiculo_compatible && r.ubicacion_fisica && r.preciocliente_refaccion);
  }

  async function guardar(values) {
    await api.put(`/refacciones/${editing.id_refaccion}`, { ...editing, ...values });
    setEditing(null);
    load();
    notify("Inventario actualizado.", "success");
  }

  const columns = [
    { key: "nombre_refaccion", label: "Refacción" },
    { key: "compatibilidad", label: "Compatibilidad", render: (r) => {
      const marca = marcasVehiculo.find((m) => m.id_marca_vehiculo === r.id_marca_vehiculo_compatible);
      const modelo = modelosVehiculo.find((m) => m.id_modelo_vehiculo === r.id_modelo_vehiculo_compatible);
      return marca ? `${marca.nombre_marca}${modelo ? " " + modelo.nombre_modelo : ""}` : "—";
    } },
    { key: "ubicacion_fisica", label: "Ubicación", render: (r) => r.ubicacion_fisica || "—" },
    { key: "preciocliente_refaccion", label: "Precio venta", render: (r) => r.preciocliente_refaccion ? `$${r.preciocliente_refaccion}` : "—" },
    { key: "estado", label: "Estado", render: (r) => (
      <span className={`badge ${estaCompleto(r) ? "badge-teal" : "badge-warn"}`}>{estaCompleto(r) ? "Completo" : "Falta info"}</span>
    ) },
  ];

  const fields = (values) => {
    const modelosDeLaMarca = modelosVehiculo.filter((m) => m.id_marca_vehiculo === Number(values?.id_marca_vehiculo_compatible));
    return [
      { name: "id_marca_refaccion", label: "Marca del repuesto", type: "select", options: marcasRefaccion.map((m) => ({ value: m.id_marca_refaccion, label: m.nombre_marca })) },
      { name: "posicion", label: "Posición (ej. Delantero derecho)" },
      { name: "id_marca_vehiculo_compatible", label: "Compatibilidad — Marca de vehículo", type: "select", options: marcasVehiculo.map((m) => ({ value: m.id_marca_vehiculo, label: m.nombre_marca })) },
      { name: "id_modelo_vehiculo_compatible", label: "Compatibilidad — Modelo de vehículo", type: "select", options: modelosDeLaMarca.map((m) => ({ value: m.id_modelo_vehiculo, label: m.nombre_modelo })) },
      { name: "id_proveedor", label: "Proveedor", type: "select", options: proveedores.map((p) => ({ value: p.id_proveedor, label: p.nombre_proveedor })) },
      { name: "sku_interno", label: "SKU / código interno" },
      { name: "codigo_barras", label: "Código de barras (UPC)" },
      { name: "preciopropio_refaccion", label: "Costo de compra", type: "number" },
      { name: "preciocliente_refaccion", label: "Precio de venta", type: "number" },
      { name: "ubicacion_fisica", label: "Ubicación física", full: true },
      { name: "zona_abc", label: "Zona de rotación (ABC)", type: "select", options: ZONAS_ABC },
    ];
  };

  return (
    <>
      <div className="page-header">
        <div>
          <h1>📦 Inventario</h1>
          <div className="subtitle">Marca, compatibilidad, proveedor, precios, SKU/UPC y ubicación por refacción</div>
        </div>
      </div>

      <div className="panel">
        {loading ? (
          <div className="loading-text">Cargando…</div>
        ) : (
          <DataTable columns={columns} rows={refacciones} onEdit={setEditing} emptyMessage="Da de alta refacciones primero en Catálogos." />
        )}
      </div>

      {editing && (
        <FormModal
          title={`Inventario — ${editing.nombre_refaccion}`}
          fields={fields}
          initialValues={editing}
          onSubmit={guardar}
          onClose={() => setEditing(null)}
        />
      )}
    </>
  );
}
