import { useEffect, useRef, useState } from "react";
import { api } from "../api";
import { useUI } from "../context/UIContext";

/**
 * Los datos que aparecen en el encabezado del recibo y la nota de
 * remisión que se le entregan al cliente — antes decían "Sistema
 * Mecánico" fijo, sin importar cuál taller lo estuviera usando.
 */
export default function ConfiguracionTaller() {
  const { notify } = useUI();
  const [data, setData] = useState(null);
  const [estados, setEstados] = useState([]);
  const [ciudades, setCiudades] = useState([]);
  const [guardando, setGuardando] = useState(false);
  const [subiendoLogo, setSubiendoLogo] = useState(false);
  const [verificacion2Pasos, setVerificacion2Pasos] = useState(() => localStorage.getItem("sm_verificacion_2_pasos") === "true");
  const inputRef = useRef(null);

  useEffect(() => {
    api.get("/configuracion-taller/").then(setData);
    api.get("/estados/").then(setEstados).catch(() => setEstados([]));
  }, []);

  useEffect(() => {
    if (!data?.id_estado) { setCiudades([]); return; }
    api.get(`/ciudades/?id_estado=${data.id_estado}`).then(setCiudades).catch(() => setCiudades([]));
  }, [data?.id_estado]);

  async function guardar() {
    setGuardando(true);
    try {
      const actualizado = await api.put("/configuracion-taller/", {
        nombre_taller: data.nombre_taller,
        direccion: data.direccion,
        telefono: data.telefono,
        correo: data.correo,
        rfc: data.rfc,
        cp: data.cp,
        calle: data.calle,
        numero_taller: data.numero_taller,
        id_estado: data.id_estado || null,
        id_ciudad: data.id_ciudad || null,
      });
      setData(actualizado);
      notify("Datos del taller actualizados.", "success");
    } catch (err) {
      notify(err.message, "error");
    } finally {
      setGuardando(false);
    }
  }

  async function subirLogo(e) {
    const archivo = e.target.files?.[0];
    e.target.value = "";
    if (!archivo) return;
    const formData = new FormData();
    formData.append("archivo", archivo);
    setSubiendoLogo(true);
    try {
      const actualizado = await api.postForm("/configuracion-taller/logo", formData);
      setData(actualizado);
      notify("Logo actualizado.", "success");
    } catch (err) {
      notify(err.message, "error");
    } finally {
      setSubiendoLogo(false);
    }
  }

  if (!data) return <div className="loading-text">Cargando…</div>;

  return (
    <>
      <div className="page-header">
        <div>
          <h1>🏢 Datos del taller</h1>
          <div className="subtitle">Esto aparece en el encabezado del recibo y la nota de remisión que se le entrega al cliente</div>
        </div>
      </div>

      <div className="panel" style={{ maxWidth: 520 }}>
        <div className="field">
          <label>Logo (opcional)</label>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            {data.ruta_logo ? (
              <img src={`/uploads/${data.ruta_logo}`} alt="Logo" style={{ width: 56, height: 56, objectFit: "contain", background: "var(--paper-0)", borderRadius: 8 }} />
            ) : (
              <div style={{ width: 56, height: 56, background: "var(--paper-0)", borderRadius: 8 }} />
            )}
            <button className="btn btn-secondary btn-sm" onClick={() => inputRef.current?.click()} disabled={subiendoLogo}>
              {subiendoLogo ? "Subiendo…" : "Cambiar logo"}
            </button>
            <input ref={inputRef} type="file" accept="image/*" style={{ display: "none" }} onChange={subirLogo} />
          </div>
        </div>

        <div className="field">
          <label>Nombre del taller</label>
          <input value={data.nombre_taller || ""} onChange={(e) => setData({ ...data, nombre_taller: e.target.value })} />
        </div>
        <div className="field">
          <label>Dirección</label>
          <input value={data.direccion || ""} onChange={(e) => setData({ ...data, direccion: e.target.value })} />
        </div>
        <div className="field">
          <label>Teléfono</label>
          <input value={data.telefono || ""} onChange={(e) => setData({ ...data, telefono: e.target.value })} />
        </div>
        <div className="field">
          <label>Correo</label>
          <input value={data.correo || ""} onChange={(e) => setData({ ...data, correo: e.target.value })} />
        </div>
        <div className="field">
          <label>RFC</label>
          <input value={data.rfc || ""} onChange={(e) => setData({ ...data, rfc: e.target.value })} />
        </div>
        <div className="field">
          <label>Código postal</label>
          <input value={data.cp || ""} onChange={(e) => setData({ ...data, cp: e.target.value })} maxLength={5} />
        </div>
        <div className="field">
          <label>Calle</label>
          <input value={data.calle || ""} onChange={(e) => setData({ ...data, calle: e.target.value })} />
        </div>
        <div className="field">
          <label>Número (exterior / de sucursal)</label>
          <input value={data.numero_taller || ""} onChange={(e) => setData({ ...data, numero_taller: e.target.value })} />
        </div>
        <div className="field">
          <label>Estado</label>
          <select value={data.id_estado || ""} onChange={(e) => setData({ ...data, id_estado: e.target.value ? Number(e.target.value) : null, id_ciudad: null })}>
            <option value="">-- Selecciona --</option>
            {estados.map((e) => <option key={e.id_estado} value={e.id_estado}>{e.nombre_estado}</option>)}
          </select>
        </div>
        <div className="field">
          <label>Municipio</label>
          <select value={data.id_ciudad || ""} onChange={(e) => setData({ ...data, id_ciudad: e.target.value ? Number(e.target.value) : null })} disabled={!data.id_estado}>
            <option value="">{data.id_estado ? "-- Selecciona --" : "Elige un estado primero"}</option>
            {ciudades.map((c) => <option key={c.id_ciudad} value={c.id_ciudad}>{c.nombre_ciudad}</option>)}
          </select>
        </div>

        <button className="btn btn-primary" onClick={guardar} disabled={guardando} style={{ marginTop: 12 }}>
          {guardando ? "Guardando…" : "Guardar"}
        </button>
      </div>

      <div className="panel" style={{ maxWidth: 520, marginTop: 20 }}>
        <h2 style={{ fontSize: 16, marginBottom: 4 }}>Seguridad</h2>
        <label style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 13.5, color: "var(--ink-700)", cursor: "pointer", marginTop: 10 }}>
          <input
            type="checkbox"
            checked={verificacion2Pasos}
            onChange={(e) => {
              setVerificacion2Pasos(e.target.checked);
              localStorage.setItem("sm_verificacion_2_pasos", e.target.checked ? "true" : "false");
            }}
          />
          Pedir verificación en 2 pasos al crear órdenes (código que confirma el cliente)
        </label>
      </div>
    </>
  );
}
