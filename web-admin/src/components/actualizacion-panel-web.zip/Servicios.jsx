import { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { api } from "../api";
import FormModal from "../components/FormModal";

const STATUS_BADGE = {
  abierto: "badge-petrol",
  cerrado: "badge-teal",
  cancelado: "badge-red",
};

const ETIQUETAS_ETAPA = {
  recibido: "Recibido",
  diagnostico: "En diagnóstico",
  esperando_autorizacion: "Esperando autorización del cliente",
  en_reparacion: "En reparación",
  esperando_refacciones: "Esperando refacciones",
  control_calidad: "Control de calidad",
  listo_entrega: "Listo para entrega",
};

export default function Servicios() {
  const [servicios, setServicios] = useState([]);
  const [status, setStatus] = useState("");
  const [creating, setCreating] = useState(false);
  const [garantiaOriginal, setGarantiaOriginal] = useState(null); // servicio original si venimos de "Reclamar garantía"
  const [clientes, setClientes] = useState([]);
  const [vehiculos, setVehiculos] = useState([]);
  const [empleados, setEmpleados] = useState([]);
  const [tiposServicio, setTiposServicio] = useState([]);
  const [loading, setLoading] = useState(true);
  const [verificacion2Pasos, setVerificacion2Pasos] = useState(() => localStorage.getItem("sm_verificacion_2_pasos") === "true");
  const [modalConfirmar, setModalConfirmar] = useState(null); // { valores, codigo } cuando está pidiendo el código
  const [codigoIngresado, setCodigoIngresado] = useState("");
  const [errorCodigo, setErrorCodigo] = useState("");
  const navigate = useNavigate();
  const location = useLocation();

  async function load() {
    setLoading(true);
    const data = await api.get(`/servicios/${status ? `?status=${status}` : ""}`);
    setServicios(data);
    setLoading(false);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status]);

  // Si llegamos aquí desde el botón "🛡️ Reclamar garantía" del detalle de
  // otra orden, abre la captura ya lista con ese cliente/vehículo.
  useEffect(() => {
    if (location.state?.garantiaOriginal) {
      setGarantiaOriginal(location.state.garantiaOriginal);
      openCreate();
      window.history.replaceState({}, ""); // evita que se reabra si recargas la página
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function openCreate() {
    const [c, v, e, t] = await Promise.all([
      api.get("/clientes/?solo_activos=true"), api.get("/vehiculos/"),
      api.get("/empleados/").catch(() => []), // si no tiene permiso de empleados, simplemente no se ofrece el selector
      api.get("/tipos-servicio/"),
    ]);
    setClientes(c);
    setVehiculos(v);
    setEmpleados(e.filter((emp) => emp.activo));
    setTiposServicio(t);
    setCreating(true);
  }

  async function handleCreate(values) {
    if (verificacion2Pasos && !values._confirmadoYa) {
      const codigo = String(Math.floor(1000 + Math.random() * 9000));
      setCreating(false); // cierra el formulario de la orden; el modal de código aparece encima
      setModalConfirmar({ valores: values, codigo });
      setCodigoIngresado("");
      setErrorCodigo("");
      return;
    }
    await crearServicio(values, verificacion2Pasos);
  }

  async function crearServicio(values, autorizado) {
    const { anticipo_tipo_pago, anticipo_monto, anticipo_efectivo, anticipo_tarjeta, _confirmadoYa, aplicar_iva, ...datosOrden } = values;
    const servicio = await api.post("/servicios/", {
      ...datosOrden,
      iva_porcentaje: aplicar_iva ? 16 : 0,
      id_cliente: Number(values.id_cliente),
      id_vehiculo: Number(values.id_vehiculo),
      id_empleado_responsable: values.id_empleado_responsable ? Number(values.id_empleado_responsable) : null,
      tipos_mantenimiento_ids: values.tipos_mantenimiento_ids || [],
      es_garantia: !!garantiaOriginal,
      id_servicio_original: garantiaOriginal?.id_servicio || null,
      autorizado_cliente: !!autorizado,
    });

    // Anticipo (opcional) — se registra como el primer pago, ya con la
    // orden creada (igual que en la app móvil).
    const montoAnticipo = anticipo_tipo_pago === "mixto"
      ? (Number(anticipo_efectivo) || 0) + (Number(anticipo_tarjeta) || 0)
      : Number(anticipo_monto) || 0;
    if (montoAnticipo > 0) {
      try {
        await api.post(`/servicios/${servicio.id_servicio}/abonos`, {
          monto_abono: montoAnticipo,
          tipo_pago: anticipo_tipo_pago || "efectivo",
          desglose_mixto_efectivo: anticipo_tipo_pago === "mixto" ? Number(anticipo_efectivo) || 0 : null,
          desglose_mixto_tarjeta: anticipo_tipo_pago === "mixto" ? Number(anticipo_tarjeta) || 0 : null,
          comentario: "Anticipo al crear la orden",
        });
      } catch (err) {
        // La orden ya se creó — un anticipo fallido no debe tirar todo el flujo.
        console.error("No se pudo registrar el anticipo:", err.message);
      }
    }

    setCreating(false);
    setGarantiaOriginal(null);
    navigate(`/servicios/${servicio.id_servicio}`);
  }

  async function confirmarYCrear() {
    if (codigoIngresado !== modalConfirmar.codigo) {
      setErrorCodigo("El código no coincide. Verifica con el cliente e intenta de nuevo.");
      return;
    }
    await crearServicio(modalConfirmar.valores, true);
    setModalConfirmar(null);
  }

  // Los campos son una función de `values`: así el selector de vehículo se
  // recalcula en cada render según el cliente que se haya elegido.
  function camposOrden(values) {
    const vehiculosDelCliente = values.id_cliente
      ? vehiculos.filter((v) => v.id_cliente === Number(values.id_cliente))
      : vehiculos;
    const campos = [
      {
        name: "id_cliente",
        label: "Cliente",
        type: "select",
        required: true,
        disabled: !!garantiaOriginal,
        options: clientes.map((c) => ({ value: c.id_cliente, label: `${c.nombre_cliente} ${c.paterno_cliente || ""} (${c.numero_cuenta})` })),
      },
      {
        name: "id_vehiculo",
        label: values.id_cliente ? "Vehículo de este cliente" : "Vehículo (elige un cliente primero)",
        type: "select",
        required: true,
        disabled: !!garantiaOriginal,
        options: vehiculosDelCliente.map((v) => ({
          value: v.id_vehiculo,
          label: `${v.placas_vehiculo || "sin placas"} — ${v.numero_cuenta}`,
        })),
      },
      { name: "nombre_servicio", label: "Descripción de la orden", required: true, full: true },
      { name: "km_llegada", label: "Kilometraje de llegada" },
      { name: "km_proximo_servicio", label: "Próximo servicio (km)" },
      { name: "aplicar_iva", label: "Aplicar IVA (16%)", type: "checkbox" },
    ];
    if (empleados.length > 0) {
      campos.push({
        name: "id_empleado_responsable",
        label: "Responsable (opcional)",
        type: "select",
        options: [{ value: "", label: "Sin asignar" }].concat(empleados.map((e) => ({ value: e.id_empleado, label: `${e.nombre} ${e.paterno || ""}` }))),
      });
    }
    if (garantiaOriginal) {
      campos.push({ name: "motivo_garantia", label: "¿Qué volvió a fallar?", type: "textarea", full: true, required: true });
    }
    campos.push({
      name: "tipos_mantenimiento_ids", label: "Tipo(s) de mantenimiento", type: "multiselect", full: true,
      options: tiposServicio.map((t) => ({ value: t.id_tipo_servicio, label: t.nombre_tipo })),
    });

    // Anticipo (opcional) — el monto cambia de forma según el tipo de pago,
    // igual que en la app móvil: un solo campo, o el desglose Efectivo/Tarjeta si es Mixto.
    campos.push({
      name: "anticipo_tipo_pago", label: "Anticipo — tipo de pago (opcional)", type: "select",
      options: [{ value: "efectivo", label: "Efectivo" }, { value: "tarjeta", label: "Pago con tarjeta" }, { value: "mixto", label: "Mixto" }],
    });
    if (values.anticipo_tipo_pago === "mixto") {
      campos.push({ name: "anticipo_efectivo", label: "Anticipo — Efectivo", type: "number" });
      campos.push({ name: "anticipo_tarjeta", label: "Anticipo — Tarjeta", type: "number" });
    } else {
      campos.push({ name: "anticipo_monto", label: "Anticipo — Monto", type: "number" });
    }
    return campos;
  }

  const fmt = (n) => `$${(n ?? 0).toLocaleString("es-MX", { minimumFractionDigits: 2 })}`;

  return (
    <>
      <div className="page-header">
        <div>
          <h1>🔧 Órdenes de servicio</h1>
          <div className="subtitle">{servicios.length} orden(es)</div>
        </div>
        <button className="btn btn-primary" onClick={openCreate}>
          🔧 Nueva orden
        </button>
      </div>

      <div className="panel">
        <div className="toolbar">
          {["", "abierto", "cerrado", "cancelado"].map((s) => (
            <button
              key={s}
              className={`btn btn-sm ${status === s ? "btn-primary" : "btn-secondary"}`}
              onClick={() => setStatus(s)}
            >
              {s === "" ? "Todas" : s[0].toUpperCase() + s.slice(1)}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="loading-text">Cargando…</div>
        ) : servicios.length === 0 ? (
          <div className="empty-state">No hay órdenes de servicio con este filtro.</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Orden</th>
                <th>Cliente</th>
                <th>Vehículo</th>
                <th>Entrada</th>
                <th>Estado</th>
                <th>Total</th>
                <th>Saldo</th>
              </tr>
            </thead>
            <tbody>
              {servicios.map((s) => (
                <tr key={s.id_servicio} style={{ cursor: "pointer" }} onClick={() => navigate(`/servicios/${s.id_servicio}`)}>
                  <td>
                    <Link to={`/servicios/${s.id_servicio}`}>{s.es_garantia && "🛡️ "}#{s.id_servicio} · {s.nombre_servicio}</Link>
                  </td>
                  <td>{s.cliente ? `${s.cliente.nombre_cliente} ${s.cliente.paterno_cliente || ""}` : "—"}</td>
                  <td>{s.vehiculo?.placas_vehiculo || "—"}</td>
                  <td>{new Date(s.fecha_entrada_servicio).toLocaleDateString("es-MX")}</td>
                  <td>
                    <span className={`badge ${STATUS_BADGE[s.status] || "badge-grey"}`}>{s.status}</span>
                    {s.status === "abierto" && s.etapa && (
                      <div style={{ fontSize: 11, color: "var(--ink-500)", marginTop: 3 }}>{ETIQUETAS_ETAPA[s.etapa] || s.etapa}</div>
                    )}
                  </td>
                  <td className="mono">{fmt(s.costos.total)}</td>
                  <td className="mono">
                    {s.pagado ? <span className="badge badge-teal">Pagado</span> : fmt(s.costos.saldo_pendiente)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {creating && (
        <FormModal
          title={garantiaOriginal ? `Reclamación de garantía — orden #${garantiaOriginal.id_servicio}` : "Nueva orden de servicio"}
          fields={camposOrden}
          initialValues={
            garantiaOriginal
              ? {
                  aplicar_iva: true,
                  id_cliente: garantiaOriginal.id_cliente,
                  id_vehiculo: garantiaOriginal.id_vehiculo,
                  nombre_servicio: `Garantía — ${garantiaOriginal.nombre_servicio}`,
                  anticipo_tipo_pago: "efectivo",
                }
              : { aplicar_iva: true, anticipo_tipo_pago: "efectivo" }
          }
          onSubmit={handleCreate}
          onClose={() => { setCreating(false); setGarantiaOriginal(null); }}
        />
      )}

      {modalConfirmar && (
        <div className="modal-backdrop" onClick={(e) => e.target === e.currentTarget && setModalConfirmar(null)}>
          <div className="modal" style={{ maxWidth: 380 }}>
            <h2 style={{ fontSize: 18 }}>Verificación en 2 pasos</h2>
            <p style={{ fontSize: 13.5, color: "var(--ink-500)", marginBottom: 10 }}>
              Dile este código al cliente y pídele que lo confirme: <b style={{ fontSize: 18, letterSpacing: 2 }}>{modalConfirmar.codigo}</b>
            </p>
            <div className="field">
              <label>Código que confirmó el cliente</label>
              <input value={codigoIngresado} onChange={(e) => setCodigoIngresado(e.target.value)} placeholder="0000" autoFocus />
            </div>
            {errorCodigo && <div className="error-text">{errorCodigo}</div>}
            <div className="modal-actions">
              <button className="btn btn-secondary" onClick={() => setModalConfirmar(null)}>Cancelar</button>
              <button className="btn btn-primary" onClick={confirmarYCrear}>Confirmar y crear orden</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
