import { useEffect, useState } from "react";
import { api } from "../api";
import DataTable from "../components/DataTable";
import FormModal from "../components/FormModal";
import { useUI } from "../context/UIContext";
import { useAuth } from "../context/AuthContext";

const CAMPOS = [
  { name: "nombre", label: "Nombre", required: true },
  { name: "paterno", label: "Apellido paterno" },
  { name: "materno", label: "Apellido materno" },
  { name: "telefono", label: "Teléfono" },
  { name: "correo", label: "Correo" },
  { name: "puesto", label: "Puesto (ej. Mecánico, Hojalatero)" },
  { name: "fecha_ingreso", label: "Fecha de ingreso", type: "date" },
];

export default function Empleados() {
  const { notify, confirmDialog } = useUI();
  const { hasPermission } = useAuth();
  const [empleados, setEmpleados] = useState([]);
  const [usuarios, setUsuarios] = useState([]);
  const [editing, setEditing] = useState(null);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const [emps, usrs] = await Promise.all([api.get("/empleados/"), api.get("/auth/usuarios")]);
    setEmpleados(emps);
    setUsuarios(usrs);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  const campos = CAMPOS.concat([
    {
      name: "id_usuario", label: "Cuenta de usuario ligada (opcional — para que vea su dashboard)",
      type: "select",
      options: [{ value: "", label: "Sin cuenta ligada" }].concat(usuarios.map((u) => ({ value: u.id_usuario, label: `${u.nombre_completo} (@${u.username})` }))),
    },
  ]);

  async function handleSave(values) {
    const payload = { ...values, id_usuario: values.id_usuario ? Number(values.id_usuario) : null };
    if (editing?.id_empleado) {
      await api.put(`/empleados/${editing.id_empleado}`, payload);
    } else {
      await api.post("/empleados/", payload);
    }
    setEditing(null);
    load();
  }

  async function handleDelete(emp) {
    const ok = await confirmDialog(`¿Dar de baja a ${emp.nombre}? Su historial como responsable de servicios se conserva.`, { danger: true });
    if (!ok) return;
    try {
      await api.del(`/empleados/${emp.id_empleado}`);
      load();
      notify("Empleado dado de baja.", "success");
    } catch (err) {
      notify(err.message, "error");
    }
  }

  return (
    <>
      <div className="page-header">
        <div>
          <h1>👷 Empleados</h1>
          <div className="subtitle">Catálogo del personal del taller — solo el Administrador General lo administra</div>
        </div>
        {hasPermission("empleados.crear") && (
          <button className="btn btn-primary" onClick={() => setEditing({})}>👷 Nuevo empleado</button>
        )}
      </div>

      <div className="panel">
        {loading ? (
          <div className="loading-text">Cargando…</div>
        ) : (
          <DataTable
            columns={[
              { key: "nombre", label: "Nombre", render: (e) => `${e.nombre} ${e.paterno || ""}` },
              { key: "puesto", label: "Puesto", render: (e) => e.puesto || "—" },
              { key: "telefono", label: "Teléfono", render: (e) => e.telefono || "—" },
              {
                key: "cuenta", label: "Cuenta",
                render: (e) => e.id_usuario ? <span className="badge badge-teal">Ligada</span> : <span className="badge badge-grey">Sin cuenta</span>,
              },
              {
                key: "activo", label: "Estado",
                render: (e) => <span className={`badge ${e.activo ? "badge-teal" : "badge-grey"}`}>{e.activo ? "Activo" : "Inactivo"}</span>,
              },
            ]}
            rows={empleados}
            onEdit={hasPermission("empleados.editar") ? setEditing : undefined}
            onDelete={hasPermission("empleados.eliminar") ? handleDelete : undefined}
            emptyMessage="No hay empleados registrados todavía."
          />
        )}
      </div>

      {editing && (
        <FormModal
          title={editing.id_empleado ? `Editar empleado — ${editing.nombre}` : "Nuevo empleado"}
          fields={campos}
          initialValues={editing}
          onSubmit={handleSave}
          onClose={() => setEditing(null)}
        />
      )}
    </>
  );
}
