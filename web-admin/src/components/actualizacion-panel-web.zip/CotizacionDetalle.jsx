import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { api, getToken } from "../api";
import FormModal from "../components/FormModal";
import { useAuth } from "../context/AuthContext";
import { useUI } from "../context/UIContext";

function BloqueNota({ icono, titulo, acento, accion, children }) {
  return (
    <div className={`nota-bloque ${acento ? `acento-${acento}` : ""}`}>
      <div className="nota-bloque-header">
        <span className="icono">{icono}</span>
        <h2>{titulo}</h2>
        {accion}
      </div>
      <div className="nota-bloque-body">{children}</div>
    </div>
  );
}

export default function CotizacionDetalle() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { hasPermission } = useAuth();
  const { notify } = useUI();
  const [cotizacion, setCotizacion] = useState(null);
  const [refacciones, setRefacciones] = useState([]);
  const [tipos, setTipos] = useState([]);
  const [datosTaller, setDatosTaller] = useState(null);
  const [comentarios, setComentarios] = useState("");
  const [guardandoComentarios, setGuardandoComentarios] = useState(false);
  const [addingDetalle, setAddingDetalle] = useState(false);
  const [descargando, setDescargando] = useState(false);
  const [pdfPreviewUrl, setPdfPreviewUrl] = useState(null);

  async function load() {
    const c = await api.get(`/cotizaciones/${id}`);
    setCotizacion(c);
    setComentarios(c.comentarios || "");
  }

  useEffect(() => {
    load();
    api.get("/refacciones/").then(setRefacciones).catch(() => setRefacciones([]));
    api.get("/tipos-servicio/").then(setTipos).catch(() => setTipos([]));
    api.get("/configuracion-taller/").then(setDatosTaller).catch(() => setDatosTaller(null));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (!cotizacion) return <div className="loading-text">Cargando…</div>;

  const fmt = (n) => `$${(n ?? 0).toLocaleString("es-MX", { minimumFractionDigits: 2 })}`;

  async function guardarComentarios() {
    setGuardandoComentarios(true);
    try {
      const actualizada = await api.put(`/cotizaciones/${id}`, { comentarios: comentarios.trim() || null });
      setCotizacion(actualizada);
      notify("Comentarios guardados.", "success");
    } catch (err) {
      notify(err.message, "error");
    } finally {
      setGuardandoComentarios(false);
    }
  }

  async function handleAddDetalle(values) {
    try {
      const refaccionElegida = values.id_refaccion ? refacciones.find((r) => r.id_refaccion === Number(values.id_refaccion)) : null;
      const actualizada = await api.post(`/cotizaciones/${id}/detalles`, {
        ...values,
        id_tipo_servicio: values.id_tipo_servicio || null,
        id_refaccion: values.id_refaccion || null,
        descripcion: values.descripcion?.trim() || refaccionElegida?.nombre_refaccion || null,
        cantidad: Number(values.cantidad || 1),
        costo_refaccion: Number(values.costo_refaccion) || (refaccionElegida?.preciocliente_refaccion ?? 0),
        costo_extra: Number(values.costo_extra || 0),
      });
      setCotizacion(actualizada);
      setAddingDetalle(false);
    } catch (err) {
      notify(err.message, "error");
    }
  }

  async function handleUpdateDetalle(detalleId, cambios) {
    try {
      const actualizada = await api.put(`/cotizaciones/${id}/detalles/${detalleId}`, cambios);
      setCotizacion(actualizada);
    } catch (err) {
      notify(err.message, "error");
      load();
    }
  }

  async function handleDeleteDetalle(detalleId) {
    try {
      const actualizada = await api.del(`/cotizaciones/${id}/detalles/${detalleId}`);
      setCotizacion(actualizada);
    } catch (err) {
      notify(err.message, "error");
    }
  }

  async function descargarPdf(modo = "descargar") {
    setDescargando(true);
    try {
      const res = await fetch(`/api/cotizaciones/${id}/pdf`, { headers: { Authorization: `Bearer ${getToken()}` } });
      if (!res.ok) {
        const data = await res.json().catch(() => null);
        throw new Error(data?.detail || "No se pudo generar el documento.");
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      if (modo === "preview") {
        setPdfPreviewUrl(url);
        return;
      }
      const a = document.createElement("a");
      a.href = url;
      a.download = `cotizacion-${id}.pdf`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      notify(err.message, "error");
    } finally {
      setDescargando(false);
    }
  }

  const puedeEditar = hasPermission("cotizaciones.editar");

  return (
    <>
      <div className="page-header">
        <div>
          <h1>🧾 {cotizacion.titulo}</h1>
          <div className="orden-cliente-vehiculo">
            Cotización #{cotizacion.id_cotizacion} · {new Date(cotizacion.fecha_cotizacion).toLocaleDateString("es-MX")}
            {cotizacion.vigente_hasta && ` · Vigente hasta ${new Date(cotizacion.vigente_hasta).toLocaleDateString("es-MX")}`}
          </div>
        </div>
        <button className="btn btn-secondary" onClick={() => navigate("/cotizaciones")}>← Volver</button>
      </div>

      {datosTaller && (
        <BloqueNota icono="🏢" titulo="Datos del taller">
          <dl className="datos-lista">
            <dt>Nombre</dt><dd>{datosTaller.nombre_taller || "—"}</dd>
            <dt>Dirección</dt><dd>{datosTaller.direccion || "—"}</dd>
            <dt>Teléfono</dt><dd>{datosTaller.telefono || "—"}</dd>
            <dt>RFC</dt><dd>{datosTaller.rfc || "—"}</dd>
          </dl>
        </BloqueNota>
      )}

      <BloqueNota icono="💰" titulo="Resumen de costos">
        <div className="kpi-grid" style={{ marginBottom: 0 }}>
          <div className="kpi-card">
            <div className="kpi-label">Subtotal</div>
            <div className="kpi-value mono">{fmt(cotizacion.costos.subtotal)}</div>
          </div>
          <div className="kpi-card">
            <div className="kpi-label">IVA ({cotizacion.iva_porcentaje}%)</div>
            <div className="kpi-value mono">{fmt(cotizacion.costos.iva)}</div>
          </div>
          <div className="kpi-card ok">
            <div className="kpi-label">Total estimado</div>
            <div className="kpi-value mono">{fmt(cotizacion.costos.total)}</div>
          </div>
        </div>
      </BloqueNota>

      <BloqueNota
        icono="🔧"
        titulo="Conceptos"
        accion={
          puedeEditar && (
            <button className="btn btn-primary btn-sm" onClick={() => setAddingDetalle(true)}>+ Agregar concepto</button>
          )
        }
      >
        {cotizacion.detalles.length === 0 ? (
          <div className="empty-state">Aún no se han agregado conceptos a esta cotización.</div>
        ) : (
          <table>
            <thead>
              <tr><th>Descripción</th><th>Refacción</th><th>Cant.</th><th>Refacción $</th><th>Extra $</th><th></th></tr>
            </thead>
            <tbody>
              {cotizacion.detalles.map((d) => {
                const ref = refacciones.find((r) => r.id_refaccion === d.id_refaccion);
                return (
                  <tr key={d.id_cotizacion_detalle}>
                    <td>{d.descripcion || "—"}</td>
                    <td>{ref?.nombre_refaccion || "—"}</td>
                    <td style={{ width: 70 }}>
                      <input
                        type="number" defaultValue={d.cantidad || 1} disabled={!puedeEditar}
                        style={{ width: "100%", padding: "4px 6px" }}
                        onBlur={(e) => { const v = Number(e.target.value) || 1; if (v !== d.cantidad) handleUpdateDetalle(d.id_cotizacion_detalle, { cantidad: v }); }}
                      />
                    </td>
                    <td style={{ width: 100 }}>
                      <input
                        type="number" defaultValue={d.costo_refaccion} disabled={!puedeEditar}
                        style={{ width: "100%", padding: "4px 6px" }}
                        onBlur={(e) => { const v = Number(e.target.value) || 0; if (v !== d.costo_refaccion) handleUpdateDetalle(d.id_cotizacion_detalle, { costo_refaccion: v }); }}
                      />
                    </td>
                    <td style={{ width: 100 }}>
                      <input
                        type="number" defaultValue={d.costo_extra} disabled={!puedeEditar}
                        style={{ width: "100%", padding: "4px 6px" }}
                        onBlur={(e) => { const v = Number(e.target.value) || 0; if (v !== d.costo_extra) handleUpdateDetalle(d.id_cotizacion_detalle, { costo_extra: v }); }}
                      />
                    </td>
                    <td>
                      {puedeEditar && <button className="btn btn-danger btn-sm" onClick={() => handleDeleteDetalle(d.id_cotizacion_detalle)}>Quitar</button>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </BloqueNota>

      <BloqueNota icono="📝" titulo="Comentarios">
        <div className="field full">
          <label>Notas o condiciones del presupuesto</label>
          <textarea value={comentarios} onChange={(e) => setComentarios(e.target.value)} disabled={!puedeEditar} />
        </div>
        {puedeEditar && (
          <button className="btn btn-secondary btn-sm" onClick={guardarComentarios} disabled={guardandoComentarios}>
            {guardandoComentarios ? "Guardando…" : "Guardar comentarios"}
          </button>
        )}
      </BloqueNota>

      <div style={{ display: "flex", justifyContent: "center" }}>
        <button className="btn btn-primary btn-preview-fijo" onClick={() => descargarPdf("preview")} disabled={descargando}>
          {descargando ? "Generando…" : "📄 Generar vista previa de la cotización"}
        </button>
      </div>

      {pdfPreviewUrl && (
        <div className="modal-backdrop" onClick={(e) => { if (e.target === e.currentTarget) { URL.revokeObjectURL(pdfPreviewUrl); setPdfPreviewUrl(null); } }}>
          <div className="modal modal-pdf">
            <div className="modal-pdf-header">
              <span>📄 Vista previa de la cotización</span>
              <div style={{ display: "flex", gap: 10 }}>
                <a className="btn btn-secondary btn-sm" href={pdfPreviewUrl} download={`cotizacion-${id}.pdf`}>Descargar</a>
                <button className="btn btn-secondary btn-sm" onClick={() => { URL.revokeObjectURL(pdfPreviewUrl); setPdfPreviewUrl(null); }}>Cerrar ✕</button>
              </div>
            </div>
            <iframe src={pdfPreviewUrl} title="Vista previa de la cotización" className="modal-pdf-frame" />
          </div>
        </div>
      )}

      {addingDetalle && (
        <FormModal
          title="Agregar concepto a la cotización"
          fields={[
            {
              name: "id_tipo_servicio", label: "Tipo de servicio", type: "select",
              options: tipos.map((t) => ({ value: t.id_tipo_servicio, label: t.nombre_tipo })),
            },
            {
              name: "id_refaccion", label: "Refacción (Parte Automotriz)", type: "select",
              options: refacciones.map((r) => ({ value: r.id_refaccion, label: `${r.nombre_refaccion} (stock: ${r.cantidad_refaccion})` })),
            },
            { name: "cantidad", label: "Cantidad", type: "number" },
            { name: "descripcion", label: "Descripción", full: true },
            { name: "costo_refaccion", label: "Costo refacción", type: "number" },
            { name: "costo_extra", label: "Costo extra", type: "number" },
          ]}
          initialValues={{ cantidad: 1 }}
          onSubmit={handleAddDetalle}
          onClose={() => setAddingDetalle(false)}
        />
      )}
    </>
  );
}
