"""Crea las tablas (si no existen) y siembra datos base:
- Catálogo completo de permisos (por módulo: ver/crear/editar/eliminar)
- Los 4 roles de la jerarquía del taller (Administrador General, Jefe de
  Taller / Receptor, Asesor de Servicio / Caja, Técnico / Mecánico) con sus
  permisos por defecto, más el mecanismo para roles personalizados
- Un usuario "Administrador General" (tomado de las variables de entorno
  ADMIN_USERNAME / ADMIN_PASSWORD)
- Catálogo geográfico de México (32 estados) y tipos de servicio comunes

Se ejecuta automáticamente al iniciar la app (ver main.py) y también puede
correrse manualmente con: python -m app.seed
"""
import os

from sqlalchemy import inspect, text

from .database import Base, engine, SessionLocal, es_sqlite
from . import models
from .security import hash_password

# --- Catálogo de permisos ---------------------------------------------------
# (clave, módulo, descripción). Los módulos con las 4 acciones estándar se
# generan con _crud(); "roles" es especial (solo ver/editar, no tiene "crear
# instancias sueltas" en el mismo sentido).
def _crud(modulo: str, etiqueta: str):
    return [
        (f"{modulo}.ver", modulo, f"Ver {etiqueta}"),
        (f"{modulo}.crear", modulo, f"Crear {etiqueta}"),
        (f"{modulo}.editar", modulo, f"Editar {etiqueta}"),
        (f"{modulo}.eliminar", modulo, f"Eliminar {etiqueta}"),
    ]


PERMISOS = (
    _crud("clientes", "clientes")
    + _crud("vehiculos", "vehículos")
    + _crud("servicios", "órdenes de servicio (incluye agregar conceptos/abonos y cerrar)")
    + _crud("cotizaciones", "cotizaciones / presupuestos")
    + _crud("refacciones", "refacciones (inventario)")
    + _crud("herramientas", "herramientas (inventario)")
    + _crud("proveedores", "proveedores y sus deudas")
    + _crud("catalogos", "catálogos generales (marcas, modelos, colores, tipos de servicio, países/estados/ciudades)")
    + _crud("usuarios", "usuarios del sistema")
    + _crud("promociones", "promociones que ven los clientes en su app")
    + _crud("empleados", "catálogo de empleados del taller (datos personales y asignación como responsables)")
    + [
        ("configuracion.editar", "configuracion", "Editar los datos del taller que aparecen en los documentos (recibo, nota de remisión)"),
        ("roles.ver", "roles", "Ver roles y sus permisos"),
        ("roles.editar", "roles", "Crear/editar/eliminar roles y asignar permisos"),
    ]
)

# --- Roles base de la jerarquía del taller ----------------------------------
PERMISOS_ADMIN_GENERAL = [clave for clave, _, _ in PERMISOS]  # todo

PERMISOS_JEFE_TALLER = [
    "clientes.ver", "clientes.editar",
    "vehiculos.ver", "vehiculos.crear", "vehiculos.editar", "vehiculos.eliminar",
    "servicios.ver", "servicios.crear", "servicios.editar", "servicios.eliminar",
    "cotizaciones.ver", "cotizaciones.crear", "cotizaciones.editar", "cotizaciones.eliminar",
    "refacciones.ver", "refacciones.crear", "refacciones.editar", "refacciones.eliminar",
    "herramientas.ver", "herramientas.editar",
    "proveedores.ver", "proveedores.editar",
    "catalogos.ver", "catalogos.crear", "catalogos.editar", "catalogos.eliminar",
    "promociones.ver", "promociones.crear", "promociones.editar", "promociones.eliminar",
]

PERMISOS_ASESOR_SERVICIO = [
    "clientes.ver",
    "vehiculos.ver",
    "servicios.ver", "servicios.crear", "servicios.editar",
    "cotizaciones.ver", "cotizaciones.crear", "cotizaciones.editar",
    "refacciones.ver",
]

# El rol "Técnico / Mecánico" es el más angosto de todos: no administra nada
# del taller, solo necesita ver las órdenes que tiene asignadas (su propio
# dashboard personal es un endpoint aparte que no depende de ningún
# permiso — cualquier usuario ligado a un empleado lo puede ver).
PERMISOS_TECNICO = [
    "servicios.ver",
]

ROLES_BASE = [
    ("Administrador General", "Acceso total al sistema.", PERMISOS_ADMIN_GENERAL),
    ("Jefe de Taller / Receptor", "Administra catálogos, promociones y vehículos/servicios/refacciones por completo; clientes, herramientas y proveedores en modo lectura/escritura (sin eliminar).", PERMISOS_JEFE_TALLER),
    ("Asesor de Servicio / Caja", "Da de alta órdenes de servicio y captura cobros; consulta clientes, vehículos y refacciones en solo lectura.", PERMISOS_ASESOR_SERVICIO),
    ("Técnico / Mecánico", "Solo ve las órdenes de servicio asignadas y su propio dashboard de trabajo — no administra nada del taller.", PERMISOS_TECNICO),
]

# Checklist estándar de inspección digital — el dueño puede desactivar
# puntos que no use desde el catálogo, no hace falta tocar código.
ITEMS_INSPECCION = {
    "Llantas": ["Presión y/o sensor de presión"],
    "Frenos": ["Balatas delanteras", "Balatas traseras", "Líquido de frenos"],
    "Luces": ["Faros delanteros", "Luces traseras", "Direccionales", "Luz de freno", "Luz de reversa"],
    "Fluidos": ["Nivel de aceite de motor", "Anticongelante/refrigerante", "Líquido limpiaparabrisas", "Líquido de dirección hidráulica"],
    "Batería y eléctrico": ["Batería (carga y terminales)", "Alternador", "Marcha"],
    "Suspensión y dirección": ["Amortiguadores delanteros", "Amortiguadores traseros", "Rótulas y terminales"],
    "Carrocería": ["Limpiaparabrisas", "Espejos", "Cinturones de seguridad"],
}

ESTADOS_MEXICO = [
    "Aguascalientes", "Baja California", "Baja California Sur", "Campeche", "Chiapas",
    "Chihuahua", "Ciudad de México", "Coahuila", "Colima", "Durango", "Estado de México",
    "Guanajuato", "Guerrero", "Hidalgo", "Jalisco", "Michoacán", "Morelos", "Nayarit",
    "Nuevo León", "Oaxaca", "Puebla", "Querétaro", "Quintana Roo", "San Luis Potosí",
    "Sinaloa", "Sonora", "Tabasco", "Tamaulipas", "Tlaxcala", "Veracruz", "Yucatán", "Zacatecas",
]

# Al menos la capital de cada estado (y León, GTO, porque es con lo que se
# probó el catálogo de códigos postales) — así el autollenado por CP
# siempre tiene una ciudad real que hacer match.
CIUDADES_POR_ESTADO = {
    "Aguascalientes": ["Aguascalientes"], "Baja California": ["Mexicali", "Tijuana"],
    "Baja California Sur": ["La Paz"], "Campeche": ["Campeche"], "Chiapas": ["Tuxtla Gutiérrez"],
    "Chihuahua": ["Chihuahua", "Ciudad Juárez"], "Ciudad de México": ["Ciudad de México"],
    "Coahuila": ["Saltillo"], "Colima": ["Colima"], "Durango": ["Durango"],
    "Estado de México": ["Toluca", "Ecatepec"], "Guanajuato": ["Guanajuato", "León"],
    "Guerrero": ["Chilpancingo", "Acapulco"], "Hidalgo": ["Pachuca"],
    "Jalisco": ["Guadalajara", "Zapopan", "Tlaquepaque"], "Michoacán": ["Morelia"],
    "Morelos": ["Cuernavaca"], "Nayarit": ["Tepic"], "Nuevo León": ["Monterrey", "San Nicolás"],
    "Oaxaca": ["Oaxaca de Juárez"], "Puebla": ["Puebla"], "Querétaro": ["Querétaro"],
    "Quintana Roo": ["Chetumal", "Cancún"], "San Luis Potosí": ["San Luis Potosí"],
    "Sinaloa": ["Culiacán"], "Sonora": ["Hermosillo"], "Tabasco": ["Villahermosa"],
    "Tamaulipas": ["Ciudad Victoria", "Reynosa"], "Tlaxcala": ["Tlaxcala"],
    "Veracruz": ["Xalapa", "Veracruz"], "Yucatán": ["Mérida"], "Zacatecas": ["Zacatecas"],
}


def _sincronizar_columnas_faltantes():
    """SQLite (a diferencia de Postgres con Alembic) no agrega columnas
    solo porque el modelo de Python ya las tenga — Base.metadata.create_all
    únicamente crea TABLAS nuevas, nunca altera una que ya existe. Sin
    esto, cada vez que se agrega un campo a un modelo (como pasó con
    Código postal/Calle/Estado en ConfiguracionTaller), cualquier consulta
    a esa tabla truena con "no such column" hasta que alguien borra la
    base de datos a mano. Esto lo hace automático, sin perder datos.
    """
    if not es_sqlite:
        return  # Postgres/SQL Server ya deberían manejarse con una migración de verdad (Alembic)

    tipos_sqlite = {
        "INTEGER": "INTEGER", "SMALLINT": "INTEGER", "BIGINT": "INTEGER",
        "BOOLEAN": "BOOLEAN", "VARCHAR": "TEXT", "TEXT": "TEXT",
        "FLOAT": "FLOAT", "NUMERIC": "FLOAT", "DATETIME": "DATETIME", "DATE": "DATE",
    }
    inspector = inspect(engine)
    tablas_existentes = set(inspector.get_table_names())
    with engine.connect() as conn:
        for tabla in Base.metadata.sorted_tables:
            if tabla.name not in tablas_existentes:
                continue  # tabla nueva por completo — ya la creó create_all()
            columnas_actuales = {c["name"] for c in inspector.get_columns(tabla.name)}
            for columna in tabla.columns:
                if columna.name in columnas_actuales:
                    continue
                tipo_sql = tipos_sqlite.get(columna.type.__class__.__name__.upper(), "TEXT")
                conn.execute(text(f'ALTER TABLE "{tabla.name}" ADD COLUMN "{columna.name}" {tipo_sql}'))
                print(f"[migración automática] agregada columna faltante: {tabla.name}.{columna.name}")
        conn.commit()


def run():
    Base.metadata.create_all(bind=engine)
    _sincronizar_columnas_faltantes()
    db = SessionLocal()
    try:
        # Permisos (se agregan los que falten; nunca se borran solos, por si
        # algún rol personalizado ya los está usando)
        existentes = {p.clave for p in db.query(models.Permiso).all()}
        for clave, modulo, descripcion in PERMISOS:
            if clave not in existentes:
                db.add(models.Permiso(clave=clave, modulo=modulo, descripcion=descripcion))
        db.commit()

        mapa_permisos = {p.clave: p for p in db.query(models.Permiso).all()}

        # Roles base (Administrador General / Jefe de Taller / Asesor de
        # Servicio / Técnico). Si ya existen no se tocan sus permisos (para
        # no pisar ajustes manuales que ya hizo el dueño) — EXCEPTO
        # Administrador General, que por definición siempre debe tener
        # TODOS los permisos; si no, cada vez que se agrega un módulo
        # nuevo (como Cotizaciones) el propio dueño se quedaría sin verlo
        # hasta borrar la base de datos a mano.
        for nombre, descripcion, claves in ROLES_BASE:
            rol = db.query(models.Rol).filter(models.Rol.nombre == nombre).first()
            if not rol:
                rol = models.Rol(
                    nombre=nombre, descripcion=descripcion, es_sistema=True,
                    permisos=[mapa_permisos[c] for c in claves if c in mapa_permisos],
                )
                db.add(rol)
            elif nombre == "Administrador General":
                rol.permisos = list(mapa_permisos.values())
        db.commit()

        rol_admin_general = db.query(models.Rol).filter(models.Rol.nombre == "Administrador General").first()

        # Usuario administrador general (el "admin" original de la app)
        admin_username = os.getenv("ADMIN_USERNAME", "admin")
        admin_password = os.getenv("ADMIN_PASSWORD", "admin1234")
        admin_correo = os.getenv("ADMIN_CORREO")  # opcional, para recibir avisos de recuperación
        if not db.query(models.Usuario).filter(models.Usuario.username == admin_username).first():
            db.add(models.Usuario(
                username=admin_username,
                hashed_password=hash_password(admin_password),
                nombre_completo="Administrador General",
                id_rol=rol_admin_general.id_rol,
                correo=admin_correo,
                activo=True,
            ))

        # Catálogo geográfico: México y sus 32 estados
        if not db.query(models.Pais).first():
            mx = models.Pais(nombre_pais="México")
            db.add(mx)
            db.flush()
            for nombre_estado in ESTADOS_MEXICO:
                db.add(models.Estado(nombre_estado=nombre_estado, id_pais=mx.id_pais))

        # Tipos de servicio comunes
        if not db.query(models.TipoServicio).first():
            for nombre in [
                "Cambio de aceite", "Afinación", "Frenos", "Suspensión",
                "Diagnóstico eléctrico", "Alineación y balanceo", "Transmisión", "Otro",
            ]:
                db.add(models.TipoServicio(nombre_tipo=nombre))

        # Colores de vehículo más comunes
        if not db.query(models.ColorVehiculo).first():
            for nombre in [
                "Blanco", "Negro", "Gris", "Plata", "Rojo", "Azul",
                "Verde", "Amarillo", "Café", "Dorado", "Naranja", "Vino",
            ]:
                db.add(models.ColorVehiculo(nombre_color=nombre))

        # Categorías y subcategorías de refacción más comunes del taller
        if not db.query(models.RefaccionCategoria).first():
            CATEGORIAS_REFACCION = {
                "Frenos": ["Balatas delanteras", "Balatas traseras", "Discos", "Líquido de frenos"],
                "Motor": ["Filtro de aceite", "Bujías", "Banda de distribución", "Aceite de motor", "Filtro de aire"],
                "Suspensión": ["Amortiguadores delanteros", "Amortiguadores traseros", "Rótulas", "Terminales"],
                "Eléctrico": ["Batería", "Alternador", "Marcha", "Fusibles"],
                "Transmisión": ["Aceite de transmisión", "Embrague", "Bandas"],
                "Refrigeración": ["Radiador", "Anticongelante", "Termostato", "Mangueras"],
                "Llantas": ["Llantas", "Válvulas", "Balanceo"],
                "Carrocería": ["Limpiaparabrisas", "Espejos", "Faros", "Molduras"],
            }
            for nombre_categoria, subcategorias in CATEGORIAS_REFACCION.items():
                categoria = models.RefaccionCategoria(nombre_categoria=nombre_categoria)
                db.add(categoria)
                db.flush()  # necesitamos su id ya asignado para ligar las subcategorías
                for nombre_sub in subcategorias:
                    db.add(models.RefaccionSubcategoria(nombre_subcategoria=nombre_sub, id_categoria_refaccion=categoria.id_categoria_refaccion))

        # Checklist por defecto de la inspección digital
        if not db.query(models.InspeccionItem).first():
            orden = 0
            for categoria, items in ITEMS_INSPECCION.items():
                for nombre_item in items:
                    orden += 1
                    db.add(models.InspeccionItem(categoria=categoria, nombre_item=nombre_item, orden=orden))

        db.commit()
    finally:
        db.close()


if __name__ == "__main__":
    run()
