import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api";
import { useUI } from "../context/UIContext";
import { useAuth } from "../context/AuthContext";

/**
 * Una sola pantalla para dos cosas relacionadas: ver todos los usuarios y
 * cambiarles el rol al vuelo (sin abrir un formulario), y al lado, una
 * referencia rápida de qué módulos puede tocar cada rol — para que quien
 * asigna sepa qué le está dando a cada persona.
 */
export default function AsignacionRoles() {
  const { notify } = useUI();
  const { user: usuarioActual, hasPermission } = useAuth();
  const [usuarios, setUsuarios] = useState([]);
  const [roles, setRoles] = useState([]);
  const [permisos, setPermisos] = useState([]);
  const [rolReferencia, setRolReferencia] = useState(null);
  const [loading, setLoading] = useState(true);
  const [guardandoId, setGuardandoId] = useState(null);
  const puedeEditar = hasPermission("usuarios.editar");

  async function load() {
    setLoading(true);
    const [u, r, p] = await Promise.all([api.get("/auth/usuarios"), api.get("/auth/roles"), api.get("/auth/permisos")]);
    setUsuarios(u);
    setRoles(r);
    setPermisos(p);
    if (!rolReferencia && r.length > 0) setRolReferencia(r[0].id_rol);
    setLoading(false);
  }

  useEffect(() => { load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  async function cambiarRol(usuario, nuevoIdRol) {
    if (Number(nuevoIdRol) === usuario.rol?.id_rol) return;
    setGuardandoId(usuario.id_usuario);
    try {
      await api.put(`/auth/usuarios/${usuario.id_usuario}`, { id_rol: Number(nuevoIdRol) });
      notify(`Rol de ${usuario.nombre_completo} actualizado.`, "success");
      load();
    } catch (err) {
      notify(err.message, "error");
    } finally {
      setGuardandoId(null);
    }
  }

  if (loading) return <div className="loading-text">Cargando…</div>;

  const rol = roles.find((r) => r.id_rol === rolReferencia);
  const modulos = [...new Set(permisos.map((p) => p.modulo))];
  const clavesDelRol = new Set((rol?.permisos || []).map((p) => p.clave));

  return (
    <>
      <div className="page-header">
        <div>
          <h1>🔗 Asignación de roles</h1>
          <div className="subtitle">
            Quién es quién y qué rol tiene cada uno ·{" "}
            <Link to="/roles">editar qué puede hacer cada rol →</Link>
          </div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.3fr 1fr", gap: 20 }}>
        <div className="panel">
          <h2 style={{ fontSize: 15, marginBottom: 12 }}>Usuarios</h2>
          <table>
            <thead><tr><th>Usuario</th><th>Nombre</th><th>Rol</th><th>Estado</th></tr></thead>
            <tbody>
              {usuarios.map((u) => (
                <tr key={u.id_usuario}>
                  <td className="mono">{u.username}</td>
                  <td>{u.nombre_completo}</td>
                  <td>
                    <select
                      value={u.rol?.id_rol || ""}
                      disabled={!puedeEditar || guardandoId === u.id_usuario || u.id_usuario === usuarioActual?.id_usuario}
                      onChange={(e) => cambiarRol(u, e.target.value)}
                      style={{ minWidth: 130 }}
                    >
                      {roles.map((r) => (
                        <option key={r.id_rol} value={r.id_rol}>{r.nombre}</option>
                      ))}
                    </select>
                    {u.id_usuario === usuarioActual?.id_usuario && (
                      <span className="field-hint" style={{ marginLeft: 6 }}>(eres tú)</span>
                    )}
                  </td>
                  <td>
                    <span className={`badge ${u.activo ? "badge-teal" : "badge-grey"}`}>{u.activo ? "Activo" : "Inactivo"}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="panel">
          <h2 style={{ fontSize: 15, marginBottom: 12 }}>¿Qué puede hacer cada rol?</h2>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 14 }}>
            {roles.map((r) => (
              <button
                key={r.id_rol}
                className={`btn btn-sm ${rolReferencia === r.id_rol ? "btn-primary" : "btn-secondary"}`}
                onClick={() => setRolReferencia(r.id_rol)}
              >
                {r.nombre}
              </button>
            ))}
          </div>

          {rol && (
            <>
              {rol.descripcion && <p style={{ fontSize: 13, color: "var(--ink-500)", marginBottom: 12 }}>{rol.descripcion}</p>}
              {modulos.map((modulo) => {
                const permisosModulo = permisos.filter((p) => p.modulo === modulo);
                const activos = permisosModulo.filter((p) => clavesDelRol.has(p.clave));
                if (activos.length === 0) return null;
                return (
                  <div key={modulo} style={{ marginBottom: 10 }}>
                    <div style={{ fontWeight: 700, fontSize: 12.5, textTransform: "capitalize" }}>{modulo}</div>
                    <div style={{ fontSize: 12, color: "var(--ink-500)" }}>
                      {activos.map((p) => p.descripcion.split(" ")[0]).join(", ")}
                    </div>
                  </div>
                );
              })}
              {modulos.every((m) => permisos.filter((p) => p.modulo === m).every((p) => !clavesDelRol.has(p.clave))) && (
                <div className="empty-state">Este rol no tiene ningún permiso asignado todavía.</div>
              )}
            </>
          )}
        </div>
      </div>
    </>
  );
}
