import { useEffect, useState } from "react";
import { api } from "../api";
import DataTable from "../components/DataTable";
import FormModal from "../components/FormModal";
import { useUI } from "../context/UIContext";
import { useAuth } from "../context/AuthContext";

// Configuración de cada catálogo simple: endpoint, llave primaria y campos del form.
const CATALOGS = {
  paises: {
    label: "Países", endpoint: "/paises", idField: "id_pais",
    fields: [{ name: "nombre_pais", label: "Nombre", required: true }],
    columns: [{ key: "nombre_pais", label: "Nombre" }],
  },
  estados: {
    label: "Estados", endpoint: "/estados", idField: "id_estado",
    fields: (deps) => [
      { name: "nombre_estado", label: "Nombre", required: true },
      { name: "id_pais", label: "País", type: "select", required: true, options: deps.paises.map((p) => ({ value: p.id_pais, label: p.nombre_pais })) },
    ],
    columns: (deps) => [
      { key: "nombre_estado", label: "Nombre" },
      { key: "pais", label: "País", render: (r) => deps.paises.find((p) => p.id_pais === r.id_pais)?.nombre_pais || "—" },
    ],
    deps: ["paises"],
  },
  ciudades: {
    label: "Ciudades", endpoint: "/ciudades", idField: "id_ciudad",
    fields: (deps) => [
      { name: "nombre_ciudad", label: "Nombre", required: true },
      { name: "id_estado", label: "Estado", type: "select", required: true, options: deps.estados.map((e) => ({ value: e.id_estado, label: e.nombre_estado })) },
    ],
    columns: (deps) => [
      { key: "nombre_ciudad", label: "Nombre" },
      { key: "estado", label: "Estado", render: (r) => deps.estados.find((e) => e.id_estado === r.id_estado)?.nombre_estado || "—" },
    ],
    deps: ["estados"],
  },
  colores: {
    label: "Colores de vehículo", endpoint: "/colores-vehiculos", idField: "id_color",
    fields: [{ name: "nombre_color", label: "Nombre", required: true }],
    columns: [{ key: "nombre_color", label: "Nombre" }],
  },
  marcasVehiculos: {
    label: "Marcas de vehículo", endpoint: "/vehiculos-marcas", idField: "id_marca_vehiculo",
    fields: [{ name: "nombre_marca", label: "Nombre", required: true }, { name: "comentarios", label: "Comentarios", type: "textarea", full: true }],
    columns: [{ key: "nombre_marca", label: "Nombre" }, { key: "comentarios", label: "Comentarios" }],
  },
  modelosVehiculos: {
    label: "Modelos de vehículo", endpoint: "/vehiculos-modelos", idField: "id_modelo_vehiculo",
    fields: (deps) => [
      { name: "nombre_modelo", label: "Nombre", required: true },
      { name: "id_marca_vehiculo", label: "Marca", type: "select", required: true, options: deps.marcasVehiculos.map((m) => ({ value: m.id_marca_vehiculo, label: m.nombre_marca })) },
      { name: "comentario", label: "Comentario", type: "textarea", full: true },
    ],
    columns: (deps) => [
      { key: "nombre_modelo", label: "Nombre" },
      { key: "marca", label: "Marca", render: (r) => deps.marcasVehiculos.find((m) => m.id_marca_vehiculo === r.id_marca_vehiculo)?.nombre_marca || "—" },
    ],
    deps: ["marcasVehiculos"],
  },
  marcasRefacciones: {
    label: "Marcas de refacciones", endpoint: "/refacciones-marcas", idField: "id_marca_refaccion",
    fields: [{ name: "nombre_marca", label: "Nombre", required: true }, { name: "comentarios", label: "Comentarios", type: "textarea", full: true }],
    columns: [{ key: "nombre_marca", label: "Nombre" }],
  },
  categoriasRefacciones: {
    label: "Categorías de refacción", endpoint: "/refacciones-categorias", idField: "id_categoria_refaccion",
    fields: [{ name: "nombre_categoria", label: "Nombre", required: true }],
    columns: [{ key: "nombre_categoria", label: "Nombre" }],
  },
  subcategoriasRefacciones: {
    label: "Subcategorías de refacción", endpoint: "/refacciones-subcategorias", idField: "id_subcategoria_refaccion",
    fields: (deps) => [
      { name: "nombre_subcategoria", label: "Nombre", required: true },
      { name: "id_categoria_refaccion", label: "Categoría", type: "select", required: true, options: deps.categoriasRefacciones.map((c) => ({ value: c.id_categoria_refaccion, label: c.nombre_categoria })) },
    ],
    columns: (deps) => [
      { key: "nombre_subcategoria", label: "Nombre" },
      { key: "categoria", label: "Categoría", render: (r) => deps.categoriasRefacciones.find((c) => c.id_categoria_refaccion === r.id_categoria_refaccion)?.nombre_categoria || "—" },
    ],
    deps: ["categoriasRefacciones"],
  },
  marcasHerramientas: {
    label: "Marcas de herramientas", endpoint: "/herramientas-marcas", idField: "id_herramienta_marca",
    fields: [{ name: "nombre_marca", label: "Nombre", required: true }, { name: "comentario", label: "Comentario", type: "textarea", full: true }],
    columns: [{ key: "nombre_marca", label: "Nombre" }],
  },
  tiposServicio: {
    label: "Tipos de servicio", endpoint: "/tipos-servicio", idField: "id_tipo_servicio",
    fields: [{ name: "nombre_tipo", label: "Nombre", required: true }],
    columns: [{ key: "nombre_tipo", label: "Nombre" }],
  },
};

export default function Catalogos() {
  const { confirmDialog, notify } = useUI();
  const { hasPermission } = useAuth();
  const [tab, setTab] = useState("paises");
  const [rows, setRows] = useState([]);
  const [deps, setDeps] = useState({});
  const [editing, setEditing] = useState(null);
  const [loading, setLoading] = useState(true);

  const config = CATALOGS[tab];
  // Al cambiar de pestaña, React repinta de inmediato con el "deps" de la
  // pestaña ANTERIOR (el nuevo todavía se está pidiendo al backend) — sin
  // este respaldo, un config.fields(deps) que espera, por ejemplo,
  // deps.marcasVehiculos truena con "Cannot read properties of undefined"
  // y se va a pantalla en blanco. Aquí se rellenan con [] los que falten.
  const depsSeguros = {};
  for (const nombreDep of config.deps || []) {
    depsSeguros[nombreDep] = deps[nombreDep] || [];
  }

  async function load() {
    setLoading(true);
    const depNames = config.deps || [];
    const depData = {};
    for (const name of depNames) {
      depData[name] = await api.get(CATALOGS[name].endpoint + "/");
    }
    setDeps(depData);
    setRows(await api.get(config.endpoint + "/"));
    setLoading(false);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab]);

  const fields = typeof config.fields === "function" ? config.fields(depsSeguros) : config.fields;
  const columns = typeof config.columns === "function" ? config.columns(depsSeguros) : config.columns;

  async function handleSave(values) {
    if (editing?.[config.idField]) {
      await api.put(`${config.endpoint}/${editing[config.idField]}`, values);
    } else {
      await api.post(`${config.endpoint}/`, values);
    }
    setEditing(null);
    load();
  }

  async function handleDelete(row) {
    const ok = await confirmDialog("¿Eliminar este registro del catálogo?", { danger: true });
    if (!ok) return;
    try {
      await api.del(`${config.endpoint}/${row[config.idField]}`);
      load();
      notify("Registro eliminado.", "success");
    } catch (err) {
      notify(err.message, "error");
    }
  }

  return (
    <>
      <div className="page-header">
        <div>
          <h1>📚 Catálogos generales</h1>
          <div className="subtitle">
            Listas usadas en clientes, vehículos y refacciones
            {!hasPermission("catalogos.editar") && <span className="role-badge">Solo lectura</span>}
          </div>
        </div>
        {hasPermission("catalogos.crear") && <button className="btn btn-primary" onClick={() => setEditing({})}>📚 Nuevo registro</button>}
      </div>

      <div className="toolbar" style={{ flexWrap: "wrap" }}>
        {Object.entries(CATALOGS).map(([key, c]) => (
          <button
            key={key}
            className={`btn btn-sm ${tab === key ? "btn-primary" : "btn-secondary"}`}
            onClick={() => setTab(key)}
          >
            {c.label}
          </button>
        ))}
      </div>

      <div className="panel">
        {loading ? (
          <div className="loading-text">Cargando…</div>
        ) : (
          <DataTable columns={columns} rows={rows} onEdit={hasPermission("catalogos.editar") ? setEditing : undefined} onDelete={hasPermission("catalogos.eliminar") ? handleDelete : undefined} emptyMessage="Sin registros en este catálogo." />
        )}
      </div>

      {editing && (
        <FormModal
          title={editing[config.idField] ? `Editar — ${config.label}` : `Nuevo — ${config.label}`}
          fields={fields}
          initialValues={editing}
          onSubmit={handleSave}
          onClose={() => setEditing(null)}
        />
      )}
    </>
  );
}
