import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { api, getToken } from "../api";
import FormModal from "../components/FormModal";
import FotoGaleria from "../components/FotoGaleria";
import EtapaTracker from "../components/EtapaTracker";
import ChatOrden from "../components/ChatOrden";
import InspeccionForm from "../components/InspeccionForm";
import { useUI } from "../context/UIContext";
import { useAuth } from "../context/AuthContext";

function BloqueNota({ icono, titulo, acento, accion, children }) {
  return (
    <div className={`nota-bloque ${acento ? `acento-${acento}` : ""}`}>
      <div className="nota-bloque-header">
        <span className="icono">{icono}</span>
        <h2>{titulo}</h2>
        {accion}
      </div>
      <div className="nota-bloque-body">{children}</div>
    </div>
  );
}

export default function ServicioDetalle() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { confirmDialog, notify } = useUI();
  const { hasPermission } = useAuth();
  const [servicio, setServicio] = useState(null);
  const [comentariosFinales, setComentariosFinales] = useState("");
  const [guardandoComentarios, setGuardandoComentarios] = useState(false);
  const [tipos, setTipos] = useState([]);
  const [refacciones, setRefacciones] = useState([]);
  const [etapas, setEtapas] = useState([]);
  const [empleados, setEmpleados] = useState([]);
  const [comisiones, setComisiones] = useState([]);
  const [reclamaciones, setReclamaciones] = useState([]);
  const [inspeccionActual, setInspeccionActual] = useState(null);
  const [mostrandoInspeccion, setMostrandoInspeccion] = useState(false);
  const [addingDetalle, setAddingDetalle] = useState(false);
  const [modoMultiple, setModoMultiple] = useState(false);
  const [seleccionMultiple, setSeleccionMultiple] = useState({});
  const [filtroCategoriaMulti, setFiltroCategoriaMulti] = useState("");
  const [filtroSubcategoriaMulti, setFiltroSubcategoriaMulti] = useState("");
  const [guardandoMultiple, setGuardandoMultiple] = useState(false);
  const [addingAbono, setAddingAbono] = useState(false);
  const [descargando, setDescargando] = useState(false);
  const [modalCierre, setModalCierre] = useState(false);
  const [textoConfirmar, setTextoConfirmar] = useState("");
  const [cerrando, setCerrando] = useState(false);
  const [chatAbierto, setChatAbierto] = useState(false);
  const [estatusAbierto, setEstatusAbierto] = useState(false);
  const [fotoVehiculo, setFotoVehiculo] = useState(null);
  const [datosTaller, setDatosTaller] = useState(null);
  const [pdfPreviewUrl, setPdfPreviewUrl] = useState(null);

  async function load() {
    const s = await api.get(`/servicios/${id}`);
    setServicio(s);
    setComentariosFinales(s.comentarios_finales || "");
    if (!s.es_garantia) {
      api.get(`/servicios/${id}/reclamaciones`).then(setReclamaciones);
    } else {
      setReclamaciones([]);
    }
    const inspecciones = await api.get(`/inspecciones/?id_servicio=${id}`);
    setInspeccionActual(inspecciones[0] || null);
    if (s.id_vehiculo) {
      api.get(`/fotos/?entidad_tipo=vehiculo&entidad_id=${s.id_vehiculo}`)
        .then((fotos) => setFotoVehiculo(fotos[0] || null))
        .catch(() => setFotoVehiculo(null));
    }
  }

  useEffect(() => {
    load();
    api.get("/tipos-servicio/").then(setTipos);
    api.get("/refacciones/").then(setRefacciones);
    api.get("/servicios/etapas-disponibles").then(setEtapas);
    api.get("/empleados/").then(setEmpleados).catch(() => setEmpleados([]));
    api.get("/comisiones/").then(setComisiones).catch(() => setComisiones([]));
    api.get("/configuracion-taller/").then(setDatosTaller).catch(() => setDatosTaller(null));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (!servicio) return <div className="loading-text">Cargando orden…</div>;

  const fmt = (n) => `$${(n ?? 0).toLocaleString("es-MX", { minimumFractionDigits: 2 })}`;
  const abierta = servicio.status === "abierto";

  async function handleAddDetalle(values) {
    try {
      // Si se eligió una refacción del catálogo y no se escribió a mano la
      // descripción o el costo, se toman directo de ahí — así el concepto
      // queda editable pero ya viene precargado con lo que se capturó en
      // el catálogo de refacciones, sin tener que volver a escribirlo.
      const refaccionElegida = values.id_refaccion ? refacciones.find((r) => r.id_refaccion === Number(values.id_refaccion)) : null;
      const actualizado = await api.post(`/servicios/${id}/detalles`, {
        ...values,
        id_tipo_servicio: values.id_tipo_servicio || null,
        id_refaccion: values.id_refaccion || null,
        descripcion: values.descripcion?.trim() || refaccionElegida?.nombre_refaccion || null,
        cantidad: Number(values.cantidad || 1),
        costo_mano_obra: Number(values.costo_mano_obra || 0),
        costo_refaccion: Number(values.costo_refaccion) || (refaccionElegida?.preciocliente_refaccion ?? 0),
        costo_extra: Number(values.costo_extra || 0),
      });
      setAddingDetalle(false);
      if (actualizado.alertas_stock?.length > 0) {
        actualizado.alertas_stock.forEach((a) => {
          notify(
            `${a.nivel === "critico" ? "🔴 Stock crítico" : "🟠 Stock bajo"}: "${a.nombre_refaccion}" — quedan ${a.cantidad_actual}`,
            a.nivel === "critico" ? "error" : "info"
          );
        });
      }
      load();
    } catch (err) {
      notify(err.message, "error");
    }
  }

  function alternarSeleccionMultiple(idRefaccion, marcada) {
    setSeleccionMultiple((prev) => {
      const copia = { ...prev };
      if (marcada) copia[idRefaccion] = { cantidad: prev[idRefaccion]?.cantidad || 1 };
      else delete copia[idRefaccion];
      return copia;
    });
  }

  function cambiarCantidadMultiple(idRefaccion, cantidad) {
    setSeleccionMultiple((prev) => ({ ...prev, [idRefaccion]: { cantidad: Math.max(1, Number(cantidad) || 1) } }));
  }

  async function guardarSeleccionMultiple() {
    const idsSeleccionados = Object.keys(seleccionMultiple);
    if (idsSeleccionados.length === 0) {
      notify("Marca al menos una refacción.", "error");
      return;
    }
    // Se valida el stock de TODAS antes de aplicar ninguna, para no dejar
    // el inventario a medias si una de varias no alcanza.
    for (const idStr of idsSeleccionados) {
      const refaccion = refacciones.find((r) => r.id_refaccion === Number(idStr));
      const cantidadPedida = seleccionMultiple[idStr].cantidad;
      if (refaccion && refaccion.cantidad_refaccion < cantidadPedida) {
        notify(`Sin stock suficiente de "${refaccion.nombre_refaccion}" (disponible: ${refaccion.cantidad_refaccion}, pedido: ${cantidadPedida}).`, "error");
        return;
      }
    }
    setGuardandoMultiple(true);
    try {
      // Una tras otra (no en paralelo) para que el descuento de inventario
      // de cada una quede reflejado antes de validar/aplicar la siguiente.
      for (const idStr of idsSeleccionados) {
        const refaccion = refacciones.find((r) => r.id_refaccion === Number(idStr));
        await api.post(`/servicios/${id}/detalles`, {
          id_refaccion: Number(idStr),
          descripcion: refaccion?.nombre_refaccion || null,
          cantidad: seleccionMultiple[idStr].cantidad,
          costo_refaccion: (refaccion?.preciocliente_refaccion ?? 0) * seleccionMultiple[idStr].cantidad,
          costo_extra: 0,
        });
      }
      notify(`${idsSeleccionados.length} refacción(es) agregadas a la orden.`, "success");
      setAddingDetalle(false);
      setModoMultiple(false);
      setSeleccionMultiple({});
      load();
    } catch (err) {
      notify(err.message, "error");
    } finally {
      setGuardandoMultiple(false);
    }
  }

  async function handleUpdateDetalle(detalleId, cambios) {
    try {
      const actualizado = await api.put(`/servicios/${id}/detalles/${detalleId}`, cambios);
      setServicio(actualizado);
    } catch (err) {
      notify(err.message, "error");
      load(); // si falló, se recarga para no dejar el número editado a medias en pantalla
    }
  }

  async function handleDeleteDetalle(detalleId) {
    const ok = await confirmDialog("¿Quitar este concepto de la orden? Si usaba una refacción, se regresa al inventario.", { danger: true });
    if (!ok) return;
    try {
      await api.del(`/servicios/${id}/detalles/${detalleId}`);
      load();
    } catch (err) {
      notify(err.message, "error");
    }
  }

  async function handleAddAbono(values) {
    try {
      const monto = values.tipo_pago === "mixto"
        ? (Number(values.desglose_mixto_efectivo) || 0) + (Number(values.desglose_mixto_tarjeta) || 0)
        : Number(values.monto_abono);
      const actualizado = await api.post(`/servicios/${id}/abonos`, {
        monto_abono: monto,
        tipo_pago: values.tipo_pago || "efectivo",
        desglose_mixto_efectivo: values.tipo_pago === "mixto" ? Number(values.desglose_mixto_efectivo) || 0 : null,
        desglose_mixto_tarjeta: values.tipo_pago === "mixto" ? Number(values.desglose_mixto_tarjeta) || 0 : null,
        comentario: values.comentario || null,
      });
      setAddingAbono(false);
      const ultimo = actualizado.abonos[actualizado.abonos.length - 1];
      if (ultimo?.cambio > 0) notify(`Pago registrado. Cambio a devolver: ${fmt(ultimo.cambio)}.`, "success");
      load();
    } catch (err) {
      notify(err.message, "error");
    }
  }

  async function cambiarStatus(nuevo) {
    if (nuevo === "cancelado") {
      const ok = await confirmDialog("¿Cancelar esta orden de servicio? Podrás reabrirla después si te equivocas.", { danger: true });
      if (!ok) return;
    }
    try {
      const actualizado = await api.put(`/servicios/${id}`, { status: nuevo });
      load();
      if (nuevo !== "abierto") notify("Estado de la orden actualizado.", "success");
      if (actualizado.alertas_stock?.length > 0) {
        actualizado.alertas_stock.forEach((a) => {
          const proveedorTexto = a.proveedor ? ` · Proveedor: ${a.proveedor.nombre}${a.proveedor.telefono ? " (" + a.proveedor.telefono + ")" : ""}` : "";
          notify(
            `${a.nivel === "critico" ? "🔴 Stock crítico" : "🟠 Stock bajo"}: "${a.nombre_refaccion}"${a.numero_refaccion ? " (" + a.numero_refaccion + ")" : ""} — quedan ${a.cantidad_actual}${proveedorTexto}`,
            a.nivel === "critico" ? "error" : "info"
          );
        });
      }
    } catch (err) {
      notify(err.message, "error");
    }
  }

  async function reasignarEmpleado(idEmpleado) {
    try {
      const actualizado = await api.put(`/servicios/${id}`, { id_empleado_responsable: idEmpleado ? Number(idEmpleado) : null });
      setServicio(actualizado);
      notify("Responsable actualizado.", "success");
    } catch (err) {
      notify(err.message, "error");
    }
  }

  async function confirmarCierre() {
    if (textoConfirmar !== "CONFIRMAR") {
      notify("Escribe la palabra CONFIRMAR, en mayúsculas, para finalizar la orden.", "error");
      return;
    }
    setCerrando(true);
    try {
      await cambiarStatus("cerrado");
      setModalCierre(false);
      setTextoConfirmar("");
    } finally {
      setCerrando(false);
    }
  }

  async function guardarComentarios() {
    setGuardandoComentarios(true);
    try {
      await api.put(`/servicios/${id}`, { comentarios_finales: comentariosFinales });
      notify("Comentarios guardados — ya aparecerán en el recibo y la nota de remisión.", "success");
    } catch (err) {
      notify(err.message, "error");
    } finally {
      setGuardandoComentarios(false);
    }
  }

  async function descargarPdf(tipo, modo = "descargar") {
    setDescargando(true);
    try {
      const ruta = tipo === "remision" ? `/api/servicios/${id}/nota-remision` : `/api/servicios/${id}/recibo`;
      const res = await fetch(ruta, { headers: { Authorization: `Bearer ${getToken()}` } });
      if (!res.ok) {
        const data = await res.json().catch(() => null);
        throw new Error(data?.detail || "No se pudo generar el documento.");
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      if (modo === "preview") {
        // Se muestra incrustado en un modal de la misma página — nada de
        // pestañas nuevas ni pop-ups: los navegadores las bloquean de
        // formas distintas e impredecibles, y así siempre funciona.
        setPdfPreviewUrl(url);
        return;
      }
      const a = document.createElement("a");
      a.href = url;
      a.download = tipo === "remision" ? `nota-remision-${id}.pdf` : `orden-${id}.pdf`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      notify(err.message, "error");
    } finally {
      setDescargando(false);
    }
  }

  return (
    <>
      <div className="page-header">
        <div>
          <h1>
            🔧 Orden #{servicio.id_servicio}
            <span className={`badge badge-${servicio.status === "abierto" ? "petrol" : servicio.status === "cerrado" ? "teal" : "red"}`} style={{ marginLeft: 12, verticalAlign: "middle" }}>
              {servicio.status}
            </span>
          </h1>
          <div className="orden-cliente-vehiculo">
            {servicio.cliente?.nombre_cliente} {servicio.cliente?.paterno_cliente} ({servicio.cliente?.numero_cuenta}) · Cuenta vehículo {servicio.vehiculo?.numero_cuenta} · Placas {servicio.vehiculo?.placas_vehiculo || "—"}
          </div>
          {hasPermission("servicios.editar") && (
            <div className="field" style={{ maxWidth: 260, marginTop: 8 }}>
              <label>Empleado responsable</label>
              <select value={servicio.id_empleado_responsable ?? ""} onChange={(e) => reasignarEmpleado(e.target.value)}>
                <option value="">Sin asignar</option>
                {empleados.filter((e) => e.activo).map((e) => (
                  <option key={e.id_empleado} value={e.id_empleado}>{e.nombre} {e.paterno || ""}</option>
                ))}
              </select>
            </div>
          )}
        </div>
      </div>

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 20 }}>
          <Link className="btn btn-secondary" to="/servicios">← Volver</Link>
          <button className="btn btn-secondary" onClick={() => descargarPdf("recibo")} disabled={descargando}>
            {descargando ? "Generando…" : "Descargar recibo"}
          </button>
          {servicio.status === "cerrado" && (
            <button className="btn btn-secondary" onClick={() => descargarPdf("remision")} disabled={descargando}>
              📋 Nota de remisión
            </button>
          )}
          <button className="btn btn-secondary" onClick={() => setMostrandoInspeccion(true)}>
            🔍 {inspeccionActual ? "Ver/editar inspección" : "Nueva inspección"}
          </button>
          {servicio.status === "cerrado" && !servicio.es_garantia && hasPermission("servicios.crear") && (
            <button
              className="btn btn-secondary"
              onClick={() => navigate("/servicios", { state: { garantiaOriginal: servicio } })}
            >
              🛡️ Reclamar garantía
            </button>
          )}
          {abierta && servicio.costos.saldo_pendiente <= 0 && (
            <button className="btn btn-primary" onClick={() => setModalCierre(true)}>Confirmar y finalizar orden</button>
          )}
          {!abierta && (
            <button className="btn btn-primary" onClick={() => cambiarStatus("abierto")}>Reabrir orden</button>
          )}
          {servicio.status !== "cancelado" && servicio.status !== "cerrado" && (
            <button className="btn btn-danger" onClick={() => cambiarStatus("cancelado")}>Cancelar</button>
          )}
        </div>

      <div className="datos-3-bloques">
        <div className="nota-bloque">
          <div className="nota-bloque-header"><span className="icono">🧑</span><h2>Datos del cliente</h2></div>
          <div className="nota-bloque-body">
            <dl className="datos-lista">
              <dt>ID / Cuenta</dt><dd>{servicio.cliente?.numero_cuenta || "—"}</dd>
              <dt>Nombre</dt><dd>{servicio.cliente?.nombre_cliente} {servicio.cliente?.paterno_cliente || ""}</dd>
              <dt>Teléfono</dt><dd>{servicio.cliente?.telefono1 || "—"}</dd>
            </dl>
          </div>
        </div>

        <div className="nota-bloque">
          <div className="nota-bloque-header"><span className="icono">🚗</span><h2>Datos del vehículo</h2></div>
          <div className="nota-bloque-body datos-vehiculo-body">
            <dl className="datos-lista">
              <dt>Marca</dt><dd>{servicio.vehiculo?.marca?.nombre_marca || "—"}</dd>
              <dt>Modelo</dt><dd>{servicio.vehiculo?.modelo?.nombre_modelo || "—"}</dd>
              <dt>Km</dt><dd>{servicio.km_llegada || "—"}</dd>
              <dt>Próximo servicio (km)</dt><dd>{servicio.km_proximo_servicio || "—"}</dd>
              <dt>Color</dt><dd>{servicio.vehiculo?.color?.nombre_color || "—"}</dd>
              <dt>Placa</dt><dd>{servicio.vehiculo?.placas_vehiculo || "—"}</dd>
              <dt>VIN</dt><dd>{servicio.vehiculo?.numserie_vehiculo || "—"}</dd>
            </dl>
            {fotoVehiculo && (
              <img
                src={`/uploads/${fotoVehiculo.ruta_archivo}`}
                alt="Vehículo del cliente"
                className="orden-foto-vehiculo"
              />
            )}
          </div>
        </div>

        <div className="nota-bloque">
          <div className="nota-bloque-header"><span className="icono">🏢</span><h2>Datos del taller</h2></div>
          <div className="nota-bloque-body">
            {datosTaller ? (
              <dl className="datos-lista">
                <dt>Nombre</dt><dd>{datosTaller.nombre_taller || "—"}</dd>
                <dt>Dirección</dt><dd>{datosTaller.direccion || "—"}</dd>
                <dt>RFC</dt><dd>{datosTaller.rfc || "—"}</dd>
                <dt>Código postal</dt><dd>{datosTaller.cp || "—"}</dd>
                <dt>Calle</dt><dd>{datosTaller.calle || "—"}</dd>
                <dt>Estado</dt><dd>{datosTaller.estado?.nombre_estado || "—"}</dd>
                <dt>Municipio</dt><dd>{datosTaller.ciudad?.nombre_ciudad || "—"}</dd>
                <dt>Número</dt><dd>{datosTaller.numero_taller || "—"}</dd>
              </dl>
            ) : (
              <div className="empty-state">Cargando…</div>
            )}
            <Link to="/configuracion-taller" className="datos-taller-editar">Editar datos del taller →</Link>
          </div>
        </div>
      </div>

      {!abierta && (
        <div className="panel" style={{ borderLeft: "4px solid var(--red-600)", padding: "12px 16px" }}>
          Esta orden está <b>{servicio.status}</b>: los conceptos y abonos ya no se pueden editar. Reábrela con el botón de arriba si necesitas hacer cambios.
        </div>
      )}

      {servicio.es_garantia && (
        <div className="panel" style={{ borderLeft: "4px solid #b5730a", padding: "12px 16px" }}>
          🛡️ <b>Esta orden es una reclamación de garantía</b> de la{" "}
          <Link to={`/servicios/${servicio.id_servicio_original}`}>orden #{servicio.id_servicio_original}</Link>.
          {servicio.motivo_garantia && <div style={{ marginTop: 6, fontSize: 13 }}>Motivo: {servicio.motivo_garantia}</div>}
        </div>
      )}

      {reclamaciones.length > 0 && (
        <div className="panel" style={{ borderLeft: "4px solid #b5730a" }}>
          <h2 style={{ fontSize: 16, marginBottom: 10 }}>🛡️ Este vehículo volvió por esto ({reclamaciones.length})</h2>
          <table>
            <thead><tr><th>Orden</th><th>Fecha</th><th>Motivo</th><th>Estatus</th></tr></thead>
            <tbody>
              {reclamaciones.map((r) => (
                <tr key={r.id_servicio} style={{ cursor: "pointer" }} onClick={() => navigate(`/servicios/${r.id_servicio}`)}>
                  <td><Link to={`/servicios/${r.id_servicio}`}>#{r.id_servicio}</Link></td>
                  <td>{new Date(r.fecha_entrada_servicio).toLocaleDateString("es-MX")}</td>
                  <td>{r.motivo_garantia || "—"}</td>
                  <td><span className={`badge ${r.status === "abierto" ? "badge-petrol" : r.status === "cerrado" ? "badge-teal" : "badge-red"}`}>{r.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <BloqueNota icono="💰" titulo="Resumen de costos">
        <div className="kpi-grid" style={{ marginBottom: 0 }}>
          <div className="kpi-card">
            <div className="kpi-label">Subtotal</div>
            <div className="kpi-value mono">{fmt(servicio.costos.subtotal)}</div>
          </div>
          <div className="kpi-card">
            <div className="kpi-label">IVA ({servicio.iva_porcentaje}%)</div>
            <div className="kpi-value mono">{fmt(servicio.costos.iva)}</div>
          </div>
          <div className="kpi-card">
            <div className="kpi-label">Total</div>
            <div className="kpi-value mono">{fmt(servicio.costos.total)}</div>
          </div>
          <div className={`kpi-card ${servicio.costos.saldo_pendiente > 0 ? "alert" : "ok"}`}>
            <div className="kpi-label">Saldo pendiente</div>
            <div className="kpi-value mono">{fmt(servicio.costos.saldo_pendiente)}</div>
          </div>
        </div>
      </BloqueNota>

      <BloqueNota
        icono="🔧"
        titulo="Refacciones"
        accion={
          <div style={{ display: "flex", gap: 8 }}>
            <button className="btn btn-secondary btn-sm" onClick={() => setAddingAbono(true)} disabled={servicio.pagado || !abierta}>
              + Registrar abono
            </button>
            <button className="btn btn-primary btn-sm" onClick={() => { setModoMultiple(false); setAddingDetalle(true); }} disabled={!abierta}>
              + Agregar refacción
            </button>
            <button className="btn btn-secondary btn-sm" onClick={() => { setModoMultiple(true); setAddingDetalle(true); }} disabled={!abierta}>
              + Varias a la vez
            </button>
          </div>
        }
      >
        {servicio.detalles.length === 0 ? (
          <div className="empty-state">Aún no se han agregado refacciones ni conceptos a esta orden.</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Descripción</th>
                <th>Tipo</th>
                <th>Refacción</th>
                <th>Cant.</th>
                <th>Refacción $</th>
                <th>Extra $</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {(() => {
                // Se agrupan por categoría/subcategoría de la refacción
                // ligada (si tiene) — así salen agrupados sin importar el
                // orden en que se fueron agregando a la orden.
                const grupos = {};
                servicio.detalles.forEach((d) => {
                  const ref = refacciones.find((r) => r.id_refaccion === d.id_refaccion);
                  const clave = ref?.categoria ? `${ref.categoria}${ref.subcategoria ? " / " + ref.subcategoria : ""}` : "Sin categoría";
                  if (!grupos[clave]) grupos[clave] = [];
                  grupos[clave].push({ d, ref });
                });
                const clavesOrdenadas = Object.keys(grupos).sort((a, b) => (a === "Sin categoría" ? 1 : b === "Sin categoría" ? -1 : a.localeCompare(b)));
                return clavesOrdenadas.map((clave) => (
                  <>
                    {clavesOrdenadas.length > 1 && (
                      <tr key={`grupo-${clave}`}>
                        <td colSpan={7} style={{ background: "var(--paper-0)", fontWeight: 700, fontSize: 12.5, color: "var(--petrol-600)" }}>{clave}</td>
                      </tr>
                    )}
                    {grupos[clave].map(({ d, ref }) => (
                      <tr key={d.id_servicio_detalle}>
                        <td>{d.descripcion || "—"}</td>
                        <td>{tipos.find((t) => t.id_tipo_servicio === d.id_tipo_servicio)?.nombre_tipo || "—"}</td>
                        <td>{ref?.nombre_refaccion || "—"}</td>
                        <td style={{ width: 70 }}>
                          <input
                            type="number" defaultValue={d.cantidad || 1} disabled={!abierta}
                            style={{ width: "100%", padding: "4px 6px" }}
                            onBlur={(e) => { const v = Number(e.target.value) || 1; if (v !== d.cantidad) handleUpdateDetalle(d.id_servicio_detalle, { cantidad: v }); }}
                          />
                        </td>
                        <td style={{ width: 100 }}>
                          <input
                            type="number" defaultValue={d.costo_refaccion} disabled={!abierta}
                            style={{ width: "100%", padding: "4px 6px" }}
                            onBlur={(e) => { const v = Number(e.target.value) || 0; if (v !== d.costo_refaccion) handleUpdateDetalle(d.id_servicio_detalle, { costo_refaccion: v }); }}
                          />
                        </td>
                        <td style={{ width: 100 }}>
                          <input
                            type="number" defaultValue={d.costo_extra} disabled={!abierta}
                            style={{ width: "100%", padding: "4px 6px" }}
                            onBlur={(e) => { const v = Number(e.target.value) || 0; if (v !== d.costo_extra) handleUpdateDetalle(d.id_servicio_detalle, { costo_extra: v }); }}
                          />
                        </td>
                        <td>
                          <button className="btn btn-danger btn-sm" onClick={() => handleDeleteDetalle(d.id_servicio_detalle)} disabled={!abierta}>Quitar</button>
                        </td>
                      </tr>
                    ))}
                  </>
                ));
              })()}
            </tbody>
          </table>
        )}

        {servicio.abonos.length > 0 && (
          <>
            <h3 style={{ fontSize: 13, textTransform: "uppercase", color: "var(--ink-700)", marginTop: 20, marginBottom: 10, paddingTop: 16, borderTop: "1px solid var(--ink-300)" }}>
              Abonos registrados
            </h3>
            <table>
              <thead>
                <tr><th>#</th><th>Fecha</th><th>Tipo de pago</th><th>Monto</th><th>Cambio</th><th>Comentario</th></tr>
              </thead>
              <tbody>
                {servicio.abonos.map((a) => {
                  const comision = comisiones.find((c) => c.tipo_pago === a.tipo_pago);
                  return (
                    <tr key={a.id_abono}>
                      <td>{a.numero_abono}</td>
                      <td>{new Date(a.fecha_pago).toLocaleDateString("es-MX")}</td>
                      <td>
                        {a.tipo_pago === "tarjeta" ? "Tarjeta" : a.tipo_pago === "mixto" ? "Mixto" : "Efectivo"}
                        {comision?.porcentaje > 0 && <div style={{ fontSize: 11, color: "var(--ink-500)" }}>Comisión: {comision.porcentaje}%</div>}
                        {a.tipo_pago === "mixto" && (
                          <div style={{ fontSize: 11, color: "var(--ink-500)" }}>Efvo: {fmt(a.desglose_mixto_efectivo)} · Tarj: {fmt(a.desglose_mixto_tarjeta)}</div>
                        )}
                      </td>
                      <td className="mono">{fmt(a.monto_abono)}</td>
                      <td className="mono">{a.cambio > 0 ? fmt(a.cambio) : "—"}</td>
                      <td>{a.comentario || "—"}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </>
        )}
      </BloqueNota>

      <BloqueNota icono="📝" titulo="Comentarios finales">
        <div className="field full">
          <label>Aparecen en el recibo y la nota de remisión</label>
          <textarea
            value={comentariosFinales}
            onChange={(e) => setComentariosFinales(e.target.value)}
            placeholder="Ej. Se recomienda revisar las balatas traseras en el próximo servicio."
          />
        </div>
        <button className="btn btn-secondary btn-sm" onClick={guardarComentarios} disabled={guardandoComentarios}>
          {guardandoComentarios ? "Guardando…" : "Guardar comentarios"}
        </button>
      </BloqueNota>

      <BloqueNota icono="📸" titulo="Fotos">
        <FotoGaleria entidadTipo="servicio" entidadId={servicio.id_servicio} puedeEditar={hasPermission("servicios.editar")} />
      </BloqueNota>

      <div style={{ display: "flex", justifyContent: "center" }}>
        <button
          className="btn btn-primary btn-preview-fijo"
          onClick={() => descargarPdf("recibo", "preview")}
          disabled={descargando}
        >
          {descargando ? "Generando…" : "📄 Generar vista previa de la nota"}
        </button>
      </div>

      {pdfPreviewUrl && (
        <div className="modal-backdrop" onClick={(e) => { if (e.target === e.currentTarget) { URL.revokeObjectURL(pdfPreviewUrl); setPdfPreviewUrl(null); } }}>
          <div className="modal modal-pdf">
            <div className="modal-pdf-header">
              <span>📄 Vista previa de la nota</span>
              <div style={{ display: "flex", gap: 10 }}>
                <a className="btn btn-secondary btn-sm" href={pdfPreviewUrl} download={`orden-${id}.pdf`}>Descargar</a>
                <button className="btn btn-secondary btn-sm" onClick={() => { URL.revokeObjectURL(pdfPreviewUrl); setPdfPreviewUrl(null); }}>Cerrar ✕</button>
              </div>
            </div>
            <iframe src={pdfPreviewUrl} title="Vista previa de la nota" className="modal-pdf-frame" />
          </div>
        </div>
      )}

      {/* Botón flotante de chat — el chat solo se despliega si lo pides */}
      {abierta && (
        <button
          className="chat-fab chat-fab-estatus"
          onClick={() => { setEstatusAbierto((v) => !v); setChatAbierto(false); }}
          title="Estatus del servicio"
        >
          🛠️
        </button>
      )}
      <button
        className="chat-fab"
        onClick={() => { setChatAbierto((v) => !v); setEstatusAbierto(false); }}
        title="Chat de la orden"
      >
        💬
      </button>
      {chatAbierto && (
        <div className="chat-flotante">
          <div className="chat-flotante-header">
            <span>💬 Chat de la orden</span>
            <button className="chat-flotante-cerrar" onClick={() => setChatAbierto(false)}>✕</button>
          </div>
          <div className="chat-flotante-body">
            <ChatOrden servicioId={servicio.id_servicio} />
          </div>
        </div>
      )}
      {estatusAbierto && (
        <div className="chat-flotante chat-flotante-estatus">
          <div className="chat-flotante-header">
            <span>🛠️ Estatus del servicio</span>
            <button className="chat-flotante-cerrar" onClick={() => setEstatusAbierto(false)}>✕</button>
          </div>
          <div className="chat-flotante-body">
            <EtapaTracker
              servicio={servicio}
              etapas={etapas}
              puedeEditar={hasPermission("servicios.editar")}
              onActualizado={setServicio}
            />
          </div>
        </div>
      )}

      {addingDetalle && !modoMultiple && (
        <FormModal
          title="Agregar refacción a la orden"
          fields={[
            {
              name: "id_tipo_servicio", label: "Tipo de servicio", type: "select",
              options: tipos.map((t) => ({ value: t.id_tipo_servicio, label: t.nombre_tipo })),
              creatable: {
                endpoint: "/tipos-servicio/", createField: "nombre_tipo", idField: "id_tipo_servicio", label: "tipo de servicio",
                onCreated: (nuevo) => setTipos((prev) => [...prev, nuevo]),
              },
            },
            {
              name: "id_refaccion", label: "Refacción (Parte Automotriz)", type: "select",
              options: [...refacciones]
                .sort((a, b) => {
                  const claveA = `${a.categoria || "zzz"} ${a.subcategoria || ""}`;
                  const claveB = `${b.categoria || "zzz"} ${b.subcategoria || ""}`;
                  return claveA.localeCompare(claveB);
                })
                .map((r) => ({
                  value: r.id_refaccion,
                  label: `${r.categoria ? `[${r.categoria}${r.subcategoria ? "/" + r.subcategoria : ""}] ` : ""}${r.nombre_refaccion} (stock: ${r.cantidad_refaccion})`,
                })),
              creatable: {
                endpoint: "/refacciones/", createField: "nombre_refaccion", idField: "id_refaccion", label: "refacción",
                onCreated: (nueva) => setRefacciones((prev) => [...prev, nueva]),
              },
            },
            { name: "cantidad", label: "Cantidad de piezas usadas", type: "number" },
            { name: "descripcion", label: "Descripción", full: true },
            { name: "costo_refaccion", label: "Costo refacción", type: "number" },
            { name: "costo_extra", label: "Costo extra", type: "number" },
          ]}
          initialValues={{ cantidad: 1 }}
          onSubmit={handleAddDetalle}
          onClose={() => setAddingDetalle(false)}
        />
      )}

      {addingDetalle && modoMultiple && (() => {
        const categoriasDisponibles = [...new Set(refacciones.map((r) => r.categoria).filter(Boolean))].sort();
        const subcategoriasDisponibles = [...new Set(
          refacciones.filter((r) => !filtroCategoriaMulti || r.categoria === filtroCategoriaMulti).map((r) => r.subcategoria).filter(Boolean)
        )].sort();
        const refaccionesFiltradas = refacciones.filter((r) =>
          (!filtroCategoriaMulti || r.categoria === filtroCategoriaMulti) &&
          (!filtroSubcategoriaMulti || r.subcategoria === filtroSubcategoriaMulti)
        );
        return (
          <div className="modal-backdrop" onClick={(e) => e.target === e.currentTarget && setAddingDetalle(false)}>
            <div className="modal" style={{ maxWidth: 560 }}>
              <h2 style={{ fontSize: 18 }}>Agregar varias refacciones</h2>
              <div className="field-hint" style={{ fontSize: 12.5, color: "var(--ink-500)", marginBottom: 10 }}>
                Filtra por categoría/subcategoría (opcional), marca las refacciones que usaste y su cantidad, y agrégalas todas de un jalón.
              </div>
              <div style={{ display: "flex", gap: 10, marginBottom: 12 }}>
                <div className="field" style={{ flex: 1 }}>
                  <label>Categoría</label>
                  <select value={filtroCategoriaMulti} onChange={(e) => { setFiltroCategoriaMulti(e.target.value); setFiltroSubcategoriaMulti(""); }}>
                    <option value="">Todas</option>
                    {categoriasDisponibles.map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div className="field" style={{ flex: 1 }}>
                  <label>Subcategoría</label>
                  <select value={filtroSubcategoriaMulti} onChange={(e) => setFiltroSubcategoriaMulti(e.target.value)}>
                    <option value="">Todas</option>
                    {subcategoriasDisponibles.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              </div>

              <div style={{ maxHeight: 320, overflowY: "auto" }}>
                {refaccionesFiltradas.length === 0 ? (
                  <div className="empty-state">No hay refacciones que coincidan con ese filtro.</div>
                ) : (
                  refaccionesFiltradas.map((r) => {
                    const marcada = !!seleccionMultiple[r.id_refaccion];
                    return (
                      <div key={r.id_refaccion} style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 0", borderBottom: "1px solid var(--ink-300)" }}>
                        <label style={{ display: "flex", alignItems: "center", gap: 8, flex: 1, cursor: "pointer" }}>
                          <input
                            type="checkbox"
                            checked={marcada}
                            onChange={(e) => alternarSeleccionMultiple(r.id_refaccion, e.target.checked)}
                          />
                          <span style={{ fontSize: 13.5 }}>
                            {r.nombre_refaccion}
                            <span style={{ display: "block", fontSize: 11.5, color: "var(--ink-500)" }}>
                              Stock: {r.cantidad_refaccion}{r.preciocliente_refaccion ? ` · $${r.preciocliente_refaccion}` : ""}
                            </span>
                          </span>
                        </label>
                        <input
                          type="number"
                          min={1}
                          value={seleccionMultiple[r.id_refaccion]?.cantidad || 1}
                          disabled={!marcada}
                          onChange={(e) => cambiarCantidadMultiple(r.id_refaccion, e.target.value)}
                          style={{ width: 64 }}
                        />
                      </div>
                    );
                  })
                )}
              </div>

              <div className="field-hint" style={{ fontSize: 12, color: "var(--ink-500)", marginTop: 10 }}>
                Se descuenta el inventario de cada una al guardar (se valida que alcance el stock antes de aplicar ninguna).
              </div>
              <button
                type="button"
                className="datos-taller-editar"
                style={{ display: "block", margin: "8px 0" }}
                onClick={() => { setModoMultiple(false); setSeleccionMultiple({}); }}
              >
                ← Agregar una por una
              </button>
              <div className="modal-actions">
                <button className="btn btn-secondary" onClick={() => { setAddingDetalle(false); setModoMultiple(false); setSeleccionMultiple({}); }}>Cancelar</button>
                <button className="btn btn-primary" onClick={guardarSeleccionMultiple} disabled={guardandoMultiple}>
                  {guardandoMultiple ? "Agregando…" : "Agregar seleccionadas"}
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {addingAbono && (
        <FormModal
          title="Registrar abono"
          fields={(values) => {
            const campos = [
              {
                name: "tipo_pago", label: "Tipo de pago", type: "select",
                options: [{ value: "efectivo", label: "Efectivo" }, { value: "tarjeta", label: "Pago con tarjeta" }, { value: "mixto", label: "Mixto" }],
              },
            ];
            if (values.tipo_pago === "mixto") {
              campos.push({ name: "desglose_mixto_efectivo", label: "Efectivo", type: "number" });
              campos.push({ name: "desglose_mixto_tarjeta", label: "Tarjeta", type: "number" });
            } else {
              campos.push({ name: "monto_abono", label: "Monto", type: "number", required: true });
            }
            campos.push({ name: "comentario", label: "Comentario", type: "textarea", full: true });
            return campos;
          }}
          initialValues={{ tipo_pago: "efectivo" }}
          onSubmit={handleAddAbono}
          onClose={() => setAddingAbono(false)}
        />
      )}

      {mostrandoInspeccion && (
        <InspeccionForm
          idVehiculo={servicio.id_vehiculo}
          idServicio={servicio.id_servicio}
          inspeccionExistente={inspeccionActual}
          refacciones={refacciones}
          onGuardado={(guardada) => { setInspeccionActual(guardada); setMostrandoInspeccion(false); }}
          onClose={() => setMostrandoInspeccion(false)}
        />
      )}

      {modalCierre && (
        <div className="modal-backdrop" onClick={(e) => e.target === e.currentTarget && setModalCierre(false)}>
          <div className="modal" style={{ maxWidth: 420 }}>
            <h2 style={{ fontSize: 19 }}>Confirmar y finalizar la orden</h2>
            <p style={{ fontSize: 13.5, color: "var(--ink-500)", marginBottom: 10 }}>
              Escribe la palabra <b>CONFIRMAR</b> (en mayúsculas) para cerrar esta orden.
            </p>
            <div className="field">
              <input value={textoConfirmar} onChange={(e) => setTextoConfirmar(e.target.value)} placeholder="CONFIRMAR" autoFocus />
            </div>
            <div className="modal-actions">
              <button className="btn btn-secondary" onClick={() => { setModalCierre(false); setTextoConfirmar(""); }}>Cancelar</button>
              <button className="btn btn-primary" onClick={confirmarCierre} disabled={cerrando}>
                {cerrando ? "Finalizando…" : "Finalizar orden"}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
