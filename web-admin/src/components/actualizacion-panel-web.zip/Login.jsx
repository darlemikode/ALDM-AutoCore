import { useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { api } from "../api";

export default function Login() {
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const [recovering, setRecovering] = useState(false);
  const [identificador, setIdentificador] = useState("");
  const [recoveryMsg, setRecoveryMsg] = useState("");
  const [recoveryLoading, setRecoveryLoading] = useState(false);

  if (user) return <Navigate to="/" replace />;

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      await login(username, password);
      navigate("/");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function handleRecoverySubmit(e) {
    e.preventDefault();
    setRecoveryLoading(true);
    setRecoveryMsg("");
    try {
      const res = await api.post("/auth/recuperar-password", { identificador });
      setRecoveryMsg(res.detail);
    } catch (err) {
      setRecoveryMsg(err.message);
    } finally {
      setRecoveryLoading(false);
    }
  }

  return (
    <div className="login-screen">
      <div className="login-card">
        <div className="brand">
          Mecánico<span>2020</span>
        </div>
        <div className="tagline">Panel de administración del taller</div>

        {!recovering ? (
          <>
            <form onSubmit={handleSubmit}>
              <div className="field-stack">
                <div className="field">
                  <label>Usuario</label>
                  <input value={username} onChange={(e) => setUsername(e.target.value)} required autoFocus />
                </div>
                <div className="field">
                  <label>Contraseña</label>
                  <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
                </div>
              </div>
              {error && <div className="error-text">{error}</div>}
              <button className="btn btn-primary" style={{ width: "100%" }} disabled={loading}>
                {loading ? "Entrando…" : "Entrar"}
              </button>
            </form>
            <button
              type="button"
              className="btn-link"
              onClick={() => { setRecovering(true); setRecoveryMsg(""); setIdentificador(""); }}
            >
              ¿Olvidaste tu contraseña?
            </button>
          </>
        ) : (
          <>
            <form onSubmit={handleRecoverySubmit}>
              <div className="field-stack">
                <div className="field">
                  <label>Usuario, correo o teléfono</label>
                  <input value={identificador} onChange={(e) => setIdentificador(e.target.value)} required autoFocus placeholder="Con lo que te registró el admin" />
                </div>
              </div>
              {recoveryMsg && <div className="recovery-msg">{recoveryMsg}</div>}
              <button className="btn btn-primary" style={{ width: "100%" }} disabled={recoveryLoading}>
                {recoveryLoading ? "Enviando…" : "Avisar al administrador"}
              </button>
            </form>
            <button type="button" className="btn-link" onClick={() => setRecovering(false)}>
              ← Volver a iniciar sesión
            </button>
          </>
        )}
      </div>
    </div>
  );
}
