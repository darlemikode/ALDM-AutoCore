import { useEffect, useState } from "react";
import { api } from "../api";
import DataTable from "../components/DataTable";
import FormModal from "../components/FormModal";
import { useUI } from "../context/UIContext";
import { useAuth } from "../context/AuthContext";

export default function Refacciones() {
  const { confirmDialog, notify } = useUI();
  const { hasPermission } = useAuth();
  const [refacciones, setRefacciones] = useState([]);
  const [marcas, setMarcas] = useState([]);
  const [proveedores, setProveedores] = useState([]);
  const [categoriasRefaccion, setCategoriasRefaccion] = useState([]);
  const [subcategoriasRefaccion, setSubcategoriasRefaccion] = useState([]);
  const [q, setQ] = useState("");
  const [soloBajoStock, setSoloBajoStock] = useState(false);
  const [editing, setEditing] = useState(null);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const params = new URLSearchParams();
    if (q) params.set("q", q);
    if (soloBajoStock) params.set("bajo_stock", "true");
    const [r, m, p, cat, subcat] = await Promise.all([
      api.get(`/refacciones/?${params}`),
      api.get("/refacciones-marcas/"),
      api.get("/proveedores/"),
      api.get("/refacciones-categorias/"),
      api.get("/refacciones-subcategorias/"),
    ]);
    setRefacciones(r);
    setMarcas(m);
    setProveedores(p);
    setCategoriasRefaccion(cat);
    setSubcategoriasRefaccion(subcat);
    setLoading(false);
  }

  useEffect(() => {
    const t = setTimeout(load, 250);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q, soloBajoStock]);

  function fields(values) {
    // La refacción guarda categoría/subcategoría como texto en la base de
    // datos (para no romper lo que ya existía antes de que hubiera
    // catálogo) — pero aquí, mientras se edita el formulario, se manejan
    // como ID (igual que cualquier otro select) y se convierten a texto
    // justo al guardar, en handleSave.
    const subcategoriasDeEstaCategoria = values.__id_categoria
      ? subcategoriasRefaccion.filter((s) => s.id_categoria_refaccion === Number(values.__id_categoria))
      : [];
    return [
      { name: "nombre_refaccion", label: "Nombre", required: true, full: true },
      { name: "numero_refaccion", label: "Número de parte" },
      {
        name: "__id_categoria", label: "Categoría", type: "select",
        options: categoriasRefaccion.map((c) => ({ value: c.id_categoria_refaccion, label: c.nombre_categoria })),
        creatable: hasPermission("catalogos.crear")
          ? {
              endpoint: "/refacciones-categorias/", createField: "nombre_categoria", idField: "id_categoria_refaccion", label: "categoría",
              onCreated: (nueva) => setCategoriasRefaccion((prev) => [...prev, nueva]),
            }
          : null,
      },
      {
        name: "__id_subcategoria", label: values.__id_categoria ? "Subcategoría" : "Subcategoría (elige una categoría primero)", type: "select",
        options: subcategoriasDeEstaCategoria.map((s) => ({ value: s.id_subcategoria_refaccion, label: s.nombre_subcategoria })),
        creatable: hasPermission("catalogos.crear") && values.__id_categoria
          ? {
              endpoint: "/refacciones-subcategorias/", createField: "nombre_subcategoria", idField: "id_subcategoria_refaccion", label: "subcategoría",
              extraFields: () => ({ id_categoria_refaccion: Number(values.__id_categoria) }),
              onCreated: (nueva) => setSubcategoriasRefaccion((prev) => [...prev, nueva]),
            }
          : null,
      },
      {
        name: "id_marca_refaccion", label: "Marca", type: "select",
        options: marcas.map((m) => ({ value: m.id_marca_refaccion, label: m.nombre_marca })),
        creatable: hasPermission("catalogos.crear")
          ? {
              endpoint: "/refacciones-marcas/", createField: "nombre_marca", idField: "id_marca_refaccion", label: "marca",
              onCreated: (nueva) => setMarcas((prev) => [...prev, nueva]),
            }
          : null,
      },
      {
        name: "id_proveedor", label: "Proveedor", type: "select",
        options: proveedores.map((p) => ({ value: p.id_proveedor, label: p.nombre_proveedor })),
        creatable: hasPermission("proveedores.crear")
          ? {
              endpoint: "/proveedores/", createField: "nombre_proveedor", idField: "id_proveedor", label: "proveedor",
              onCreated: (nuevo) => setProveedores((prev) => [...prev, nuevo]),
            }
          : null,
      },
      { name: "cantidad_refaccion", label: "Cantidad en stock", type: "number" },
      { name: "preciopropio_refaccion", label: "Precio de costo", type: "number" },
      { name: "preciocliente_refaccion", label: "Precio al cliente", type: "number" },
    ];
  }

  async function handleSave(values) {
    const { __id_categoria, __id_subcategoria, ...datos } = values;
    datos.categoria = __id_categoria ? categoriasRefaccion.find((c) => c.id_categoria_refaccion === Number(__id_categoria))?.nombre_categoria || null : null;
    datos.subcategoria = __id_subcategoria ? subcategoriasRefaccion.find((s) => s.id_subcategoria_refaccion === Number(__id_subcategoria))?.nombre_subcategoria || null : null;
    if (editing?.id_refaccion) {
      await api.put(`/refacciones/${editing.id_refaccion}`, datos);
    } else {
      await api.post("/refacciones/", datos);
    }
    setEditing(null);
    load();
  }

  function abrirParaEditar(row) {
    // La refacción trae categoría/subcategoría como texto — se busca su
    // fila correspondiente en el catálogo para precargar el select con el
    // ID correcto (si el texto no coincide con nada del catálogo, como
    // pasaría con datos antiguos ya renombrados, el select abre vacío).
    const categoriaEncontrada = categoriasRefaccion.find((c) => c.nombre_categoria === row.categoria);
    const subcategoriaEncontrada = subcategoriasRefaccion.find((s) => s.nombre_subcategoria === row.subcategoria);
    setEditing({
      ...row,
      __id_categoria: categoriaEncontrada?.id_categoria_refaccion || "",
      __id_subcategoria: subcategoriaEncontrada?.id_subcategoria_refaccion || "",
    });
  }

  async function handleDelete(r) {
    const ok = await confirmDialog(`¿Eliminar "${r.nombre_refaccion}" del inventario?`, { danger: true });
    if (!ok) return;
    try {
      await api.del(`/refacciones/${r.id_refaccion}`);
      load();
      notify("Refacción eliminada.", "success");
    } catch (err) {
      notify(err.message, "error");
    }
  }

  function nombreMarca(id) { return marcas.find((m) => m.id_marca_refaccion === id)?.nombre_marca || "—"; }
  const fmt = (n) => `$${(n ?? 0).toLocaleString("es-MX", { minimumFractionDigits: 2 })}`;

  return (
    <>
      <div className="page-header">
        <div>
          <h1>⚙️ Refacciones</h1>
          <div className="subtitle">Inventario de partes del taller</div>
        </div>
        <button className="btn btn-primary" onClick={() => setEditing({})}>⚙️ Nueva refacción</button>
      </div>

      <div className="panel">
        <div className="toolbar">
          <input className="search-input" placeholder="Buscar por nombre o número de parte…" value={q} onChange={(e) => setQ(e.target.value)} />
          <button className={`btn btn-sm ${soloBajoStock ? "btn-primary" : "btn-secondary"}`} onClick={() => setSoloBajoStock((v) => !v)}>
            Solo stock bajo
          </button>
        </div>

        {loading ? (
          <div className="loading-text">Cargando…</div>
        ) : (
          <DataTable
            columns={[
              { key: "nombre_refaccion", label: "Nombre" },
              { key: "numero_refaccion", label: "Número de parte" },
              { key: "categoria", label: "Categoría", render: (r) => r.categoria ? `${r.categoria}${r.subcategoria ? " / " + r.subcategoria : ""}` : "—" },
              { key: "marca", label: "Marca", render: (r) => nombreMarca(r.id_marca_refaccion) },
              {
                key: "cantidad_refaccion", label: "Stock",
                render: (r) => (
                  <span className={`badge ${r.cantidad_refaccion <= 3 ? "badge-red" : "badge-teal"}`}>
                    {r.cantidad_refaccion}
                  </span>
                ),
              },
              { key: "preciocliente_refaccion", label: "Precio cliente", render: (r) => fmt(r.preciocliente_refaccion) },
            ]}
            rows={refacciones}
            onEdit={abrirParaEditar}
            onDelete={hasPermission("refacciones.eliminar") ? handleDelete : undefined}
            emptyMessage="No hay refacciones registradas."
          />
        )}
      </div>

      {editing && (
        <FormModal
          title={editing.id_refaccion ? "Editar refacción" : "Nueva refacción"}
          fields={fields}
          initialValues={editing}
          onSubmit={handleSave}
          onClose={() => setEditing(null)}
        />
      )}
    </>
  );
}
