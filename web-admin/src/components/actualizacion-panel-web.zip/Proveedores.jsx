import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api";
import DataTable from "../components/DataTable";
import FormModal from "../components/FormModal";
import { useUI } from "../context/UIContext";
import { useAuth } from "../context/AuthContext";

const FIELDS = [
  { name: "nombre_proveedor", label: "Nombre", required: true, full: true },
  { name: "empresa_proveedor", label: "Empresa" },
  { name: "rfc_proveedor", label: "RFC" },
  { name: "telefono1_proveedor", label: "Teléfono principal" },
  { name: "telefono2_proveedor", label: "Teléfono secundario" },
  { name: "correo_proveedor", label: "Correo" },
  { name: "calle_proveedor", label: "Calle" },
  { name: "numexterior_proveedor", label: "Número ext." },
  { name: "numinterior_proveedor", label: "Número int." },
  { name: "colonia_proveedor", label: "Colonia" },
];

export default function Proveedores() {
  const { confirmDialog, notify } = useUI();
  const { hasPermission } = useAuth();
  const [proveedores, setProveedores] = useState([]);
  const [editing, setEditing] = useState(null);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    setProveedores(await api.get("/proveedores/"));
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function handleSave(values) {
    if (editing?.id_proveedor) {
      await api.put(`/proveedores/${editing.id_proveedor}`, values);
    } else {
      await api.post("/proveedores/", values);
    }
    setEditing(null);
    load();
  }

  async function handleDelete(p) {
    const ok = await confirmDialog(`¿Eliminar al proveedor "${p.nombre_proveedor}"?`, { danger: true });
    if (!ok) return;
    try {
      await api.del(`/proveedores/${p.id_proveedor}`);
      load();
      notify("Proveedor eliminado.", "success");
    } catch (err) {
      notify(err.message, "error");
    }
  }

  return (
    <>
      <div className="page-header">
        <div>
          <h1>🚚 Proveedores</h1>
          <div className="subtitle">
            {proveedores.length} proveedor(es)
            {!hasPermission("proveedores.crear") && <span className="role-badge">Solo lectura</span>}
          </div>
        </div>
        {hasPermission("proveedores.crear") && <button className="btn btn-primary" onClick={() => setEditing({})}>🚚 Nuevo proveedor</button>}
      </div>

      <div className="panel">
        {loading ? (
          <div className="loading-text">Cargando…</div>
        ) : (
          <DataTable
            columns={[
              { key: "nombre", label: "Nombre", render: (p) => <Link to={`/proveedores/${p.id_proveedor}`}>{p.nombre_proveedor}</Link> },
              { key: "empresa_proveedor", label: "Empresa" },
              { key: "telefono1_proveedor", label: "Teléfono" },
              { key: "correo_proveedor", label: "Correo" },
            ]}
            rows={proveedores}
            onEdit={hasPermission("proveedores.editar") ? setEditing : undefined}
            onDelete={hasPermission("proveedores.eliminar") ? handleDelete : undefined}
            emptyMessage="No hay proveedores registrados."
          />
        )}
      </div>

      {editing && (
        <FormModal
          title={editing.id_proveedor ? "Editar proveedor" : "Nuevo proveedor"}
          fields={FIELDS}
          initialValues={editing}
          onSubmit={handleSave}
          onClose={() => setEditing(null)}
        />
      )}
    </>
  );
}
