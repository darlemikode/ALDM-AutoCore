import { useEffect, useState } from "react";
import { api } from "../api";
import { useUI } from "../context/UIContext";
import { useAuth } from "../context/AuthContext";

export default function Roles() {
  const { confirmDialog, notify } = useUI();
  const { hasPermission } = useAuth();
  const [roles, setRoles] = useState([]);
  const [permisos, setPermisos] = useState([]);
  const [seleccionado, setSeleccionado] = useState(null); // id_rol activo en el panel de edición
  const [borrador, setBorrador] = useState({ nombre: "", descripcion: "", permisos: [] });
  const [creando, setCreando] = useState(false);
  const [loading, setLoading] = useState(true);
  const puedeEditar = hasPermission("roles.editar");

  async function load() {
    setLoading(true);
    const [r, p] = await Promise.all([api.get("/auth/roles"), api.get("/auth/permisos")]);
    setRoles(r);
    setPermisos(p);
    setLoading(false);
    return r;
  }

  useEffect(() => {
    load().then((r) => {
      if (r.length > 0) seleccionar(r[0]);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function seleccionar(rol) {
    setCreando(false);
    setSeleccionado(rol.id_rol);
    setBorrador({ nombre: rol.nombre, descripcion: rol.descripcion || "", permisos: rol.permisos.map((p) => p.clave) });
  }

  function iniciarNuevoRol() {
    setCreando(true);
    setSeleccionado(null);
    setBorrador({ nombre: "", descripcion: "", permisos: [] });
  }

  function alternarPermiso(clave) {
    setBorrador((b) => ({
      ...b,
      permisos: b.permisos.includes(clave) ? b.permisos.filter((c) => c !== clave) : [...b.permisos, clave],
    }));
  }

  function alternarModulo(clavesModulo, todasActivas) {
    setBorrador((b) => ({
      ...b,
      permisos: todasActivas
        ? b.permisos.filter((c) => !clavesModulo.includes(c))
        : Array.from(new Set([...b.permisos, ...clavesModulo])),
    }));
  }

  async function guardar() {
    if (!borrador.nombre.trim()) {
      notify("Ponle un nombre al rol.", "error");
      return;
    }
    try {
      if (creando) {
        const nuevo = await api.post("/auth/roles", borrador);
        notify(`Rol "${nuevo.nombre}" creado.`, "success");
        const actualizados = await load();
        const creado = actualizados.find((r) => r.id_rol === nuevo.id_rol);
        if (creado) seleccionar(creado);
      } else {
        await api.put(`/auth/roles/${seleccionado}`, borrador);
        notify("Rol actualizado.", "success");
        const actualizados = await load();
        const editado = actualizados.find((r) => r.id_rol === seleccionado);
        if (editado) seleccionar(editado);
      }
    } catch (err) {
      notify(err.message, "error");
    }
  }

  async function eliminar() {
    const rol = roles.find((r) => r.id_rol === seleccionado);
    if (!rol) return;
    const ok = await confirmDialog(`¿Eliminar el rol "${rol.nombre}"? Esto no se puede deshacer.`, { danger: true });
    if (!ok) return;
    try {
      await api.del(`/auth/roles/${seleccionado}`);
      notify("Rol eliminado.", "success");
      const actualizados = await load();
      if (actualizados.length > 0) seleccionar(actualizados[0]);
      else { setSeleccionado(null); setBorrador({ nombre: "", descripcion: "", permisos: [] }); }
    } catch (err) {
      notify(err.message, "error");
    }
  }

  if (loading) return <div className="loading-text">Cargando…</div>;

  const rolActual = roles.find((r) => r.id_rol === seleccionado);
  const modulos = [...new Set(permisos.map((p) => p.modulo))];

  return (
    <>
      <div className="page-header">
        <div>
          <h1>🛡️ Roles y permisos</h1>
          <div className="subtitle">Administrador General, Jefe de Taller, Asesor de Servicio, Técnico, y cualquier rol adicional que necesites</div>
        </div>
        {puedeEditar && <button className="btn btn-primary" onClick={iniciarNuevoRol}>🛡️ Nuevo rol</button>}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "220px 1fr", gap: 20 }}>
        <div className="panel" style={{ padding: 10 }}>
          {roles.map((r) => (
            <div
              key={r.id_rol}
              onClick={() => seleccionar(r)}
              className={`nav-link ${seleccionado === r.id_rol && !creando ? "active" : ""}`}
              style={{ color: seleccionado === r.id_rol && !creando ? undefined : "var(--ink-900)", cursor: "pointer", marginBottom: 2 }}
            >
              {r.nombre}
              {r.es_sistema && <span style={{ opacity: 0.6, fontSize: 11 }}> (base)</span>}
            </div>
          ))}
        </div>

        <div className="panel">
          {(rolActual || creando) ? (
            <>
              <div className="form-grid" style={{ marginBottom: 16 }}>
                <div className="field">
                  <label>Nombre del rol</label>
                  <input
                    value={borrador.nombre}
                    disabled={!puedeEditar}
                    onChange={(e) => setBorrador((b) => ({ ...b, nombre: e.target.value }))}
                  />
                </div>
                <div className="field full">
                  <label>Descripción</label>
                  <input
                    value={borrador.descripcion}
                    disabled={!puedeEditar}
                    onChange={(e) => setBorrador((b) => ({ ...b, descripcion: e.target.value }))}
                  />
                </div>
              </div>

              {!creando && rolActual?.es_sistema && (
                <div className="field-hint" style={{ marginBottom: 14 }}>
                  Este es uno de los 4 roles base del taller (Administrador General / Jefe de Taller / Asesor de Servicio / Técnico) — se puede ajustar qué permisos tiene, pero no se puede eliminar.
                </div>
              )}

              {modulos.map((modulo) => {
                const permisosModulo = permisos.filter((p) => p.modulo === modulo);
                const clavesModulo = permisosModulo.map((p) => p.clave);
                const todasActivas = clavesModulo.every((c) => borrador.permisos.includes(c));
                return (
                  <div key={modulo} style={{ marginBottom: 14 }}>
                    <div className="card-row" style={{ marginBottom: 6 }}>
                      <div style={{ fontWeight: 700, fontSize: 13, textTransform: "capitalize" }}>{modulo}</div>
                      {puedeEditar && (
                        <button className="btn btn-secondary btn-sm" onClick={() => alternarModulo(clavesModulo, todasActivas)}>
                          {todasActivas ? "Quitar todos" : "Marcar todos"}
                        </button>
                      )}
                    </div>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
                      {permisosModulo.map((p) => (
                        <label key={p.clave} className="auth-check" style={{ margin: 0, cursor: puedeEditar ? "pointer" : "default" }}>
                          <input
                            type="checkbox"
                            disabled={!puedeEditar}
                            checked={borrador.permisos.includes(p.clave)}
                            onChange={() => alternarPermiso(p.clave)}
                          />
                          <span style={{ fontSize: 13 }}>{p.descripcion}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                );
              })}

              {puedeEditar && (
                <div className="modal-actions" style={{ justifyContent: "flex-start", marginTop: 20 }}>
                  <button className="btn btn-primary" onClick={guardar}>
                    {creando ? "Crear rol" : "Guardar cambios"}
                  </button>
                  {!creando && !rolActual?.es_sistema && (
                    <button className="btn btn-danger" onClick={eliminar}>Eliminar rol</button>
                  )}
                </div>
              )}
            </>
          ) : (
            <div className="empty-state">Selecciona un rol de la lista, o crea uno nuevo.</div>
          )}
        </div>
      </div>
    </>
  );
}
