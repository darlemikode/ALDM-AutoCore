import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api";
import DataTable from "../components/DataTable";
import FormModal from "../components/FormModal";
import { useUI } from "../context/UIContext";
import { useAuth } from "../context/AuthContext";

export default function Usuarios() {
  const { confirmDialog, notify } = useUI();
  const { user: usuarioActual, hasPermission } = useAuth();
  const [usuarios, setUsuarios] = useState([]);
  const [roles, setRoles] = useState([]);
  const [solicitudes, setSolicitudes] = useState([]);
  const [editing, setEditing] = useState(null); // null=cerrado, {}=crear, {...}=editar
  const [loading, setLoading] = useState(true);
  const [tempPassword, setTempPassword] = useState(null); // { username, password_temporal }

  async function load() {
    setLoading(true);
    const [u, r, s] = await Promise.all([
      api.get("/auth/usuarios"),
      api.get("/auth/roles"),
      hasPermission("usuarios.ver") ? api.get("/auth/solicitudes-recuperacion?solo_pendientes=true") : Promise.resolve([]),
    ]);
    setUsuarios(u);
    setRoles(r);
    setSolicitudes(s);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  const fields = [
    { name: "username", label: "Usuario (para iniciar sesión)", required: true },
    { name: "password", label: "Contraseña", type: "password", required: true },
    { name: "nombre_completo", label: "Nombre completo", required: true, full: true },
    {
      name: "id_rol", label: "Rol", type: "select", required: true,
      options: roles.map((r) => ({ value: r.id_rol, label: r.nombre })),
    },
    { name: "correo", label: "Correo (para recuperar acceso)" },
    { name: "telefono", label: "Teléfono (para recuperar acceso)" },
  ];

  // Al editar no se cambia la contraseña desde aquí (eso es autoservicio de
  // cada quien, o vía "Generar contraseña temporal" en una solicitud).
  const fieldsEditar = fields.filter((f) => f.name !== "password");

  async function handleSave(values) {
    if (editing?.id_usuario) {
      await api.put(`/auth/usuarios/${editing.id_usuario}`, values);
    } else {
      await api.post("/auth/usuarios", values);
    }
    setEditing(null);
    load();
  }

  async function handleDesactivar(u) {
    const ok = await confirmDialog(`¿Desactivar a "${u.nombre_completo}"? Ya no podrá iniciar sesión.`, { danger: true });
    if (!ok) return;
    try {
      await api.put(`/auth/usuarios/${u.id_usuario}/desactivar`);
      load();
      notify("Usuario desactivado.", "success");
    } catch (err) {
      notify(err.message, "error");
    }
  }

  async function resolverSolicitud(s) {
    const ok = await confirmDialog(
      `Se generará una contraseña temporal para "${s.usuario?.nombre_completo}". Tendrás que comunicársela tú (llamada, WhatsApp, en persona) — el sistema no envía correos/SMS automáticos.`,
      { title: "Generar contraseña temporal" }
    );
    if (!ok) return;
    try {
      const res = await api.post(`/auth/solicitudes-recuperacion/${s.id_solicitud}/resolver`);
      setTempPassword(res);
      load();
    } catch (err) {
      notify(err.message, "error");
    }
  }

  return (
    <>
      <div className="page-header">
        <div>
          <h1>👤 Usuarios</h1>
          <div className="subtitle">
            Cuentas de acceso al panel y a la app móvil ·{" "}
            <Link to="/roles">ver roles y permisos →</Link>
          </div>
        </div>
        {hasPermission("usuarios.crear") && (
          <button className="btn btn-primary" onClick={() => setEditing({})}>👤 Nuevo usuario</button>
        )}
      </div>

      {solicitudes.length > 0 && (
        <div className="panel" style={{ borderLeft: "4px solid var(--red-600)" }}>
          <h2 style={{ fontSize: 16, marginBottom: 10 }}>
            🔔 {solicitudes.length} solicitud{solicitudes.length > 1 ? "es" : ""} de recuperación de acceso
          </h2>
          <table>
            <thead>
              <tr><th>Usuario</th><th>Escribió</th><th>Fecha</th><th></th></tr>
            </thead>
            <tbody>
              {solicitudes.map((s) => (
                <tr key={s.id_solicitud}>
                  <td>{s.usuario?.nombre_completo || "—"} ({s.usuario?.username})</td>
                  <td className="mono">{s.identificador_usado}</td>
                  <td>{new Date(s.fecha_solicitud).toLocaleString("es-MX")}</td>
                  <td><button className="btn btn-primary btn-sm" onClick={() => resolverSolicitud(s)}>Generar contraseña temporal</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <div className="panel">
        {loading ? (
          <div className="loading-text">Cargando…</div>
        ) : (
          <DataTable
            columns={[
              { key: "username", label: "Usuario" },
              { key: "nombre_completo", label: "Nombre" },
              { key: "contacto", label: "Contacto", render: (u) => u.correo || u.telefono || "—" },
              { key: "rol", label: "Rol", render: (u) => <span className="role-badge">{u.rol?.nombre}</span> },
              { key: "activo", label: "Estado", render: (u) => (u.activo ? "Activo" : "Inactivo") },
            ]}
            rows={usuarios}
            onEdit={hasPermission("usuarios.editar") ? (u) => setEditing({ ...u, id_rol: u.rol?.id_rol }) : undefined}
            onDelete={hasPermission("usuarios.eliminar") ? (u) => (u.activo && u.id_usuario !== usuarioActual?.id_usuario ? handleDesactivar(u) : null) : undefined}
            emptyMessage="No hay usuarios registrados."
          />
        )}
      </div>

      {editing && (
        <FormModal
          title={editing.id_usuario ? `Editar usuario — ${editing.username}` : "Nuevo usuario"}
          fields={editing.id_usuario ? fieldsEditar : fields}
          initialValues={editing}
          onSubmit={handleSave}
          onClose={() => setEditing(null)}
        />
      )}

      {tempPassword && (
        <div className="modal-backdrop" onClick={(e) => e.target === e.currentTarget && setTempPassword(null)}>
          <div className="modal" style={{ maxWidth: 400 }}>
            <h2 style={{ fontSize: 19 }}>Contraseña temporal</h2>
            <p style={{ color: "var(--ink-500)", fontSize: 14 }}>
              Para <b>{tempPassword.username}</b>. Comunícasela tú mismo — no se envió por ningún medio automático.
              Pídele que la cambie en cuanto entre (sidebar → "Cambiar contraseña").
            </p>
            <div className="mono" style={{ background: "var(--paper-0)", padding: "12px 16px", borderRadius: 8, fontSize: 18, textAlign: "center", letterSpacing: 1 }}>
              {tempPassword.password_temporal}
            </div>
            <div className="modal-actions">
              <button className="btn btn-primary" onClick={() => setTempPassword(null)}>Listo</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
